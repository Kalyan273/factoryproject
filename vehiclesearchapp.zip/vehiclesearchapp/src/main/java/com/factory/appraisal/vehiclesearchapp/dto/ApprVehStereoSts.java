package com.factory.appraisal.vehiclesearchapp.dto;


//kalyan
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotNull;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ApprVehStereoSts {


    @NotNull(message = "Factory Equipment Operational shouldn't be empty")
    private boolean factoryEquptOperat ;
    @NotNull(message = "Factory Equipment NotOperational shouldn't be empty")
    private boolean factoryEquptNotOperat ;
    @NotNull(message = "Knobs Missing shouldn't be empty")
    private boolean knobsMissing ;
    @NotNull(message = "After Market NavigationNice System shouldn't be empty")
    private boolean aftMktNavigaNiceSys ;
    @NotNull(message = "After Market shouldn't be empty")
    private boolean afterMarket;
    @NotNull(message = "After Market Rear Entertainment System shouldn't be empty")
    private boolean aftMktRearEntertainSys ;
    @NotNull(message = "Factory Rear Entertainment System shouldn't be empty")
    private boolean factoryRearEntertainSys ;
    @NotNull(message = "Professional Install shouldn't be empty")
    private boolean profInstall ;
    @NotNull(message = "BrokenScreen shouldn't be empty")
    private boolean brokenScreen ;
    @NotNull(message = "FadedDisplayButtons shouldn't be empty")
    private boolean fadedDisBtn ;
    @NotNull(message = "NotOperational shouldn't be empty")
    private boolean notOperational ;
    @NotNull(message = "Operational shouldn't be empty")
    private boolean operational ;

}