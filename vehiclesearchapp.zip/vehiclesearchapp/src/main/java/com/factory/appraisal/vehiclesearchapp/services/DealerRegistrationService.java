package com.factory.appraisal.vehiclesearchapp.services;

import com.factory.appraisal.vehiclesearchapp.dto.DealerRegistration;


public interface DealerRegistrationService {

    /**
     *this Method will create dealer taking DealerRegistration Object as argument
     * and returning a message
     * @param dealerRegistration
     * @return
     */

    String createDealer(DealerRegistration dealerRegistration);

}
