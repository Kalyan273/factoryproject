package com.factory.appraisal.vehiclesearchapp.persistence.model;
//@author:Rupesh Khade

import com.factory.appraisal.vehiclesearchapp.constants.AppraisalConstants;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.envers.AuditTable;
import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;
import org.hibernate.annotations.Parameter;

import javax.persistence.*;
@Audited
@AuditTable(value = "APR_VEH_AC_CONDN_AUD", schema = "FACTORY_AUD")
@Entity
@Table(name = "APR_VEH_AC_CONDN",schema = "FACTORY_DB")
@Getter
@Setter

@NoArgsConstructor
@AllArgsConstructor
@DynamicUpdate
@DynamicInsert
@AttributeOverride(name = "id", column = @Column(name = "AC_CONDN_ID"))
@AttributeOverride(name = "valid", column = @Column(name = "IS_ACTIVE"))
@AttributeOverride(name="createdBy",column =@Column(name = "CREATED_BY"))
@AttributeOverride(name="createdOn",column =@Column(name = "CREATED_ON"))
@AttributeOverride(name=" modifiedBy",column =@Column(name = "MODIFIED_BY"))
@AttributeOverride(name="modifiedOn",column =@Column(name = "MODIFIED_ON"))

@GenericGenerator(name = AppraisalConstants.SEQUENCE_NAME,
        strategy = AppraisalConstants.CUSTOM_SEQUENCE_GENERATOR,
        parameters = {@Parameter(name = "sequence", value = "APR_VEH_AC_CONDN_SEQ")})
public class EApprVehAcCondn extends TransactionEntity {

    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    @OneToOne(targetEntity = EApprTestDrSts.class, fetch = FetchType.LAZY,cascade = CascadeType.ALL)
    @JoinColumn(name = "VEH_STATUS_ID",referencedColumnName = "VEH_STATUS_ID",nullable = false)
    private EApprTestDrSts vehicleStatus;
    @Column(name = "COLD_AIR")
    private boolean coldAir;
    @Column(name = "BAD_DISPLAY")
    private boolean badDisplay;
    @Column(name = "FADED_DIS_OR_BTNS")
    private boolean fadedDisOrBtn;
    @Column(name = "FAN_SPEED_MALFUNC")
    private boolean fanSpeedMalfun;
    @Column(name = "CLIMATE_CONTR_MALFUNC")
    private boolean climateCtrlMalfun;
    @Column(name = "HOT_OR_WARM_AIR")
    private boolean hotOrWarmAir;
    @Column(name = "NOT_OPRNAL")
    private boolean notOperational;


}
