package com.factory.appraisal.vehiclesearchapp.controller;
//@author:Rupesh Khade,kalyan

import com.factory.appraisal.vehiclesearchapp.ExceptionHandle.Response;
import com.factory.appraisal.vehiclesearchapp.dto.ApprCreaPage;

import com.factory.appraisal.vehiclesearchapp.dto.VideoResponse;
import com.factory.appraisal.vehiclesearchapp.responseHandler.ApiResponseHandler;
import com.factory.appraisal.vehiclesearchapp.services.AppraiseVehicleServiceImpl;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.*;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.persistence.EntityNotFoundException;
import javax.validation.constraints.Min;


@RestController
@CrossOrigin(origins = "*")
@RequestMapping("appraisal")
@Api(tags = "Appraisal vehicle", value = "Appraisal Module")
public class AppraisalVehicleController {

    @Autowired
    private AppraiseVehicleServiceImpl service;


//    @ApiOperation(value = "Add Appraisal", response = AppraisalCreationPage.class)

    /**
     * This method creates new Appraisal of vehicle
     * @param apprCreaPage this is model of AppraisalCreation page coming from ui
     * @param userId this  User id coming in header from ui
     * @return Response class
     */
    @PostMapping("/addAppraiseVehicle")
    public ResponseEntity<Response> addAppraiseVehicle(@RequestBody ApprCreaPage apprCreaPage, @RequestHeader("userId") Long userId) {
        Response response = new Response();
        try {
            if ((null != apprCreaPage) || (null != userId)) {
                String message = service.addAppraiseVehicle(apprCreaPage, userId);
                response.setCode(HttpStatus.OK.value());
                response.setMessage(message);
                return new ResponseEntity<>(response, HttpStatus.ACCEPTED);
            } else throw new EntityNotFoundException();
        } catch (EntityNotFoundException ex) {
            Response response1 = new Response();
            response.setCode(HttpStatus.BAD_REQUEST.value());
            response.setMessage(("unable to find user with id:" + userId));
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }

    }

    /**
     * This method updates the Appraisal of vehicle
     * @param apprCreaPage  this is model of AppraisalCreation page coming from ui
     * @param apprRef  this is Appraisal ref id coming in header from ui
     * @return  Response class
     */
    @ApiOperation(value = "update Appraisal by AppraisalRef id ", response = Response.class)
    @PostMapping("/updateAppraiseVehicle")
    public ResponseEntity<Response> updateAppraiseVehicle(@RequestBody ApprCreaPage apprCreaPage, @RequestHeader("id") Long apprRef) {
        try {
            if (null != apprRef) {
                Response response = service.updateAppraisal(apprCreaPage, apprRef);
                return new ResponseEntity<>(response, HttpStatus.OK);
            } else throw new EntityNotFoundException();
        } catch (EntityNotFoundException ex) {
            Response response1 = new Response();
            response1.setCode(HttpStatus.BAD_REQUEST.value());
            response1.setMessage(("unable to find vehiclecard with :" + apprRef));
            return new ResponseEntity<>(response1, HttpStatus.BAD_REQUEST);
        }
    }

    /**
     * This method sends list of Appraisal cards and pagination information  to ui
      * @param userId  this  User id coming in header from ui
     * @param pageNo   this is page number given by ui
     * @param pageSize  this is Number of records per page given by ui
     * @return   Response class
     */
    @ApiOperation(value = "get Appraisals cards by user id ", response = Response.class)
    @PostMapping("/getAppraisalsCards")
    public ResponseEntity<Response> getAppraisalsCards(@RequestHeader("userId") Long userId, @RequestParam @Min(1) Integer pageNo, @RequestParam @Min(1) Integer pageSize) {

        Response apv = service.findAllCards(userId, pageNo, pageSize);

        return new ResponseEntity<Response>(apv, HttpStatus.OK);

    }

    /**
     *   This methods sends the image of a car base on image name
     * @param pic1 this is the name of image given by ui
     * @return  byte[]
     */
    @ApiOperation(value = "get Image by image name ", response = byte[].class)
    // @PostMapping("/getpic1")
    @GetMapping("/getpic1")
    public ResponseEntity<byte[]> downloadImageFromFileSystem(@RequestParam String pic1)  {
        byte[] bytes = service.downloadImageFromFileSystem(pic1);
        return ResponseEntity.status(HttpStatus.OK)
                .contentType(MediaType.valueOf("image/jpeg"))
                .body(bytes);
    }

    /**
     *  This method saves the image coming from ui and returns the uuid.jpg i.e file name
     * @param file  MultipartFile data coming from ui
     * @return  file name in Response class
     */
    @ApiOperation(value = "Upload Image and Returns image name", response = Response.class)
    @PostMapping("/uploadImage")
    public ResponseEntity<Response> uploadImage(@RequestBody MultipartFile file) {

        try {
            if (null != file) {
                String map = service.imageUpload(file);
                Response response = new Response();
                response.setCode(HttpStatus.OK.value());
                response.setMessage(map);
                return new ResponseEntity<>(response, HttpStatus.OK);
            } else throw new NullPointerException("image cann't be empty");
        } catch (NullPointerException ex) {
            Response response = new Response();
            response.setCode(HttpStatus.BAD_REQUEST.value());
            response.setMessage(ex.getMessage());
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }


    }

    /**
     * This method sends the Appraisal Creation page to ui in Edit page
     * @param AppraisalId   this is Appraisal ref id coming in header from ui
     * @return Response class
     */
    @ApiOperation(value = "showing data to UI in editing page",response = ApprCreaPage.class)
    @PostMapping("/showToUi")
    public ResponseEntity<Response> showToUi(@RequestHeader("AppraisalId") Long AppraisalId) {
        Response page = service.showInEditPage(AppraisalId);
        return new ResponseEntity<>(page, HttpStatus.OK);

    }

    /**
     *  This method saves the video in local folder and returns the file name
     * @param file MultipartFile data coming from ui
     * @return  Response class
     */
    @ApiOperation(value = "Upload Video and Returns Video name", response = ApiResponseHandler.class)
    @PostMapping("/uploadVideo")
    public ResponseEntity<Response> uploadVideo(@RequestBody MultipartFile file) {

        try {
            if (null != file) {
                String map = service.videoUpload(file);

                Response response = new Response();
                response.setCode(HttpStatus.OK.value());
                response.setMessage(map);

                return new ResponseEntity<>(response, HttpStatus.OK);
            } else throw new NullPointerException("video can't be empty");
        } catch (NullPointerException ex) {
            Response response = new Response();
            response.setCode(HttpStatus.BAD_REQUEST.value());
            response.setMessage(ex.getMessage());
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }
    }

    /**
     *  This method sends the video to ui
     * @param filename this is file name coming from ui
     * @return byte[]
     */
    @ApiOperation(value = "Download Video", response = Resource.class)
    @GetMapping(value = "/downloadVideo")
    public ResponseEntity<byte[]> downloadVideo(@RequestParam("filename") String filename) {


            VideoResponse response = service.videoDownload(filename);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
            headers.setContentDisposition(ContentDisposition.builder("inline").filename(filename).build());

            return new ResponseEntity<>(response.getVideoBytes(), headers, HttpStatus.OK);


    }

    /**
     * This method delete the Appraisal and returns the message
     * @param apprRef  this is Appraisal ref id coming in header from ui
     * @return Response class
     *
     */
    @ApiOperation(value = "Delete Appraisal  by Appraisal Id")
    @PostMapping("/deleteAppraisal")
    public ResponseEntity<Response> deleteAppraisal(@RequestParam Long apprRef){
        return new ResponseEntity<>(service.deleteAppraisalVehicle(apprRef),HttpStatus.OK);

    }



}
