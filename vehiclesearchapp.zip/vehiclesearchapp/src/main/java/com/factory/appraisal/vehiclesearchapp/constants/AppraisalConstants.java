package com.factory.appraisal.vehiclesearchapp.constants;

import javax.persistence.Column;
import javax.validation.constraints.NotNull;

public class AppraisalConstants {

    public static final String IMAGE_FOLDER_PATH="C://myfile/";
    public static final String SEQUENCE_NAME = "mygen";

    public static final String CUSTOM_SEQUENCE_GENERATOR = "com.factory.appraisal.vehiclesearchapp.persistence.generator.CustomIDGenerator";
    public static final String VIDEO_FOLDER_PATH="C://myVideoFile/";


    public static final String COLD_AIR="coldAir";
    public static final String BAD_DISPLAY="badDisplay";
    public static final String FADED_DISORBTN="fadedDisOrBtn";
    public static final String FANSPEEDMALFUN="fanSpeedMalfun";
    public static final String CLIMATECTRLMALFUN="climateCtrlMalfun";
    public static final String HOTORWARMAIR="hotOrWarmAir";
    public static final String NOTOPERATIONAL="notOperational";
    public static final String CLEANFL="CleanFL" ;
    public static final String GOODMNRREPAISNEED ="goodMnrRepaisNeed";
    public static final String SMOKERSCAR="smokersCar" ;
    public static final String ODDSMELLING="oddSmelling" ;
    public static final String VERYDIRTY="veryDirty" ;
    public static final String STRONGPETSMELL="strongPetSmell" ;
    public static final String DRIVERSSEATWEAR ="driversSeatWear" ;
    public static final String HEADLINENEEDRPLC="headlineNeedRplc" ;
    public static final String DRIVERSEATRIPPED="driverSeatRipped";
    public static final String DASHCRACKEDMINOR="dashCrackedMinor" ;
    public static final String DASHCRACKBRKNMAJ ="dashCrackBrknMaj";
    public static final String PASSENSEATRIPPED="passenSeatRipped" ;
    public static final String CARPETBADLYWORN="carpetBadlyWorn" ;
    public static final String INTERTRIMBRKNNMISS="interTrimBrknnMiss" ;
    public static final String POORNEEDSREPAIR="poorNeedsRepair" ;
    public static final String CLEANOIL="cleanOil" ;
    public static final String DIRTYOIL="dirtyOil" ;
    public static final String WATERINOIL="waterInOil";
    public static final String CORRECTLEVEL="correctLevel" ;
    public static final String  ONEQUARTLOW="oneQuartLow" ;
    public static final String GREATERTHANAQUARTLOW ="greaterThanAQuartLow" ;
    public static final String ELECTRONICGAUGE ="electronicGauge";
    public static final String FACTORYEQUPTOPERAT="factoryEquptOperat" ;
    public static final String FACTORYEQUPTNOTOPERAT ="factoryEquptNotOperat";
    public static final String KNOBSMISSING="knobsMissing" ;
    public static final String AFTMKTNAVIGANICESYS="aftMktNavigaNiceSys" ;
    public static final String AFTERMARKET="afterMarket";
    public static final String AFTMKTREARENTERTAINSYS ="aftMktRearEntertainSys";
    public static final String FACTORYREARENTERTAINSYS="factoryRearEntertainSys" ;
    public static final String PROFINSTALL="profInstall" ;
    public static final String BROKENSCREEN="brokenScreen" ;
    public static final String FADEDDISBTN="fadedDisBtn" ;
    public static final String OPERATIONAL="operational" ;
    public static final String TIREWIDTH="tireWidth";
    public static final String FOURMATCH="fourMatch";
    public static final String MISMATCHED="mismatched";
    public static final String EXCELLENTTREAD="excellentTread";
    public static final String GOODTREAD="goodTread";
    public static final String POORTREAD="poorTread";
    public static final String NEEDSREPLACEMENT="needsReplacement";
    public static final String FRONTUNEVENWEARPTRN="frontUnevenWearPtrn";
    public static final String FRONTTIRESBAD="frontTiresBad";
    public static final String REARTIRESBAD="rearTiresBad";
    public static final String NOSPARETIRE="noSpareTire";
    public static final String SPARETIREONVEHICLE="spareTireOnVehicle";
    public static final String NOFAULTS="noFaults";
    public static final String ABSLIGHT="absLight";
    public static final String AIRBAGFAULT="airBagFault";
    public static final String BATTERYFAULT="batteryFault";
    public static final String BRAKESYSTEM="brakeSystem";
    public static final String BRAKEPADWEAR="brakePadWear";
    public static final String CHARGINGSYSTEM="chargingSystem";
    public static final String COOLANTLEVEL="coolantLevel";
    public static final String COOLANTTEMP="coolantTemp";
    public static final String CHECKENGINELIGHT="checkEngineLight";
    public static final String OILPRESSURE="oilPressure";
    public static final String SERVICEENGINESOON="serviceEngineSoon";
    public static final String STEERINGFAULTS="steeringFaults";
    public static final String SUSPENSIONSYSTEM="suspensionSystem";
    public static final String TRACTIONCONTROL="tractionControl";
    public static final String TRANSMIFAULT="transmiFault";
    public static final String DISLEXHFLUIDLIGHT="dislExhFluidLight";
    public static final String DISLPARTICULATEFILT="dislParticulateFilt";
    
}
