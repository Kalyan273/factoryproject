package com.factory.appraisal.vehiclesearchapp.services;
/**
 *
 */


import com.factory.appraisal.vehiclesearchapp.dto.ConfigCodes;

import java.util.List;


public interface ConfigurationCodesService {
    /**
     * This method inserts configCodes
     * @param configCodes
     * @return
     */

    public String addConfigCode(List<ConfigCodes> configCodes);


    /*List<ConfigurationCodes> GetConfigCodes(Integer pageNo, Integer pageSize);
    ConfigurationCodes updateConfigCodes(long codeId,ConfigurationCodes configurationCodes);
    String deleteConfigCodes(long codeId);*/

}
