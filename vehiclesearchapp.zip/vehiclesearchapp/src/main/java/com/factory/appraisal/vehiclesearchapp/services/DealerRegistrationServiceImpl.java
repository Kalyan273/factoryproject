package com.factory.appraisal.vehiclesearchapp.services;

/**
 * DealerRegistration method is taking the dealerRegistration object as input and creating user
 * @author Kalyan
 */


import com.factory.appraisal.vehiclesearchapp.controller.DealerRegistrationController;
import com.factory.appraisal.vehiclesearchapp.dto.DealerRegistration;
import com.factory.appraisal.vehiclesearchapp.persistence.mapper.AppraisalVehicleMapper;
import com.factory.appraisal.vehiclesearchapp.persistence.model.EDealerRegistration;
import com.factory.appraisal.vehiclesearchapp.repository.DealerRegistrationRepo;
import com.factory.appraisal.vehiclesearchapp.repository.RoleRepo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class DealerRegistrationServiceImpl implements DealerRegistrationService{

    Logger log = LoggerFactory.getLogger(DealerRegistrationController.class);

    @Autowired
    private DealerRegistrationRepo dealerRegistrationRepo;
@Autowired
private RoleRepo roleRepo;

    @Autowired
    private AppraisalVehicleMapper appraisalVehicleMapper;

    /**
     * this method is creating dealer
     * it is taking dealer registration object from UI and returning
     * a message i.e dealer has been saved
     * @param dealerRegistration
     * @return
     */
    @Override
    public String createDealer(DealerRegistration dealerRegistration) {
        EDealerRegistration eDealerRegistration=appraisalVehicleMapper.dealerRegToEdealerReg(dealerRegistration);
        eDealerRegistration.setRole(roleRepo.findByRole("dealer"));
        EDealerRegistration save=dealerRegistrationRepo.save(eDealerRegistration);
//        DealerRegistration dealerRegistration1=appraisalVehicleMapper.EdealerRegToDealerReg(save);
         return "Dealer Has Been saved Successfully";
    }
}
