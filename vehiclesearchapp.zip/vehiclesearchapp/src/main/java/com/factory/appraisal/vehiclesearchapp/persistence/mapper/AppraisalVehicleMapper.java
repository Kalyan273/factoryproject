package com.factory.appraisal.vehiclesearchapp.persistence.mapper;
//@author:Rupesh Khade

import com.factory.appraisal.vehiclesearchapp.dto.*;

import com.factory.appraisal.vehiclesearchapp.persistence.model.*;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface AppraisalVehicleMapper {


    EDealerRegistration AppCreaPageToEDealrReg(ApprCreaPage apprCreaPage);
    List<ApprCreaPage> lEDealRegToLApprCreatPage (List<EDealerRegistration> eDealerRegistrationList);



    EApprTestDrSts AppCreaPageToEAppTestDrSts(ApprCreaPage apprCreaPage);
    List<ApprCreaPage> lEApprTestDrStsToLApprCreatPage (List<EApprTestDrSts> eAppraisalTestDriveStatusList);

    EApprVehAcCondn AppCreaPageToEAppVehAcCond(ApprCreaPage apprCreaPage);
    List<ApprCreaPage> lEApprVehAcCondToLApprCreatPage (List<EApprVehAcCondn> eApprVehAcCondnList);

    EApprVehInteriCondn AppCreaPageToEAppIntCond(ApprCreaPage apprCreaPage);
    List<ApprCreaPage> lEApprVehIntCondToLApprCreatPage (List<EApprVehInteriCondn> eApprVehInteriCondnList);

    EApprVehOilCondn AppCreaPageToEAppOilCond(ApprCreaPage apprCreaPage);
    List<ApprCreaPage> lEApprVehOilCondToLApprCreatPage (List<EApprVehOilCondn> eApprVehOilCondnList);

    EApprVehStereoSts AppCreaPageToEAppStereoCond(ApprCreaPage apprCreaPage);
    List<ApprCreaPage> lEStereoStsToLApprCreatPage (List<EApprVehStereoSts> eApprVehStereoStsList);

    EApprVehTireCondn AppCreaPageToEAppTireCond(ApprCreaPage apprCreaPage);
    List<ApprCreaPage> lEApprVehTireCondToLApprCreatPage (List<EApprVehTireCondn> eApprVehTireCondnList);

    EVehDrWarnLightSts AppCreaPageToEVehDrWarnLightSts(ApprCreaPage apprCreaPage);
    List<ApprCreaPage> lEVehDrgwarnLgtStsToLApprCreatPage (List<EVehDrWarnLightSts> eVehDrWarnLightStsList);




    EAppraiseVehicle AppCreaPageToEAppVehCond(ApprCreaPage apprCreaPage);
    List<ApprCreaPage> lEApprVehiToLApprCreatPage (List<EAppraiseVehicle> eAppraiseVehicleList);
    AppraiseVehicle eApprVehiToApprVehicle (EAppraiseVehicle eAppraiseVehicle);
    EAppraiseVehicle apprVehiToEapprVehi(AppraiseVehicle appraiseVehicle);
    List<EAppraiseVehicle> lApprVehiToLeApprVehi (List<AppraiseVehicle> appraiseVehicleList);
    List<AppraiseVehicle> leApprVehiToLapprVehi (List<EAppraiseVehicle> eAppraiseVehicleList);




    AppraisalVehicleCard eApprVehiToApprVehiCard(EAppraiseVehicle eAppraiseVehicle);
    List<AppraisalVehicleCard> lEApprVehiToLApprVehiCard (List<EAppraiseVehicle> eAppraiseVehicleList);


    ConfigCodes eConfigCodeToConfigCode(EConfigurationCodes econfigurationCodes);
    EConfigurationCodes configCodeToEConfigCode(ConfigCodes configCodes);

   List<ConfigCodes> lEConfigCodeToConfigCode(List <EConfigurationCodes> econfigurationCodes);
   List <EConfigurationCodes> lConfigCodeToEConfigCode(List <ConfigCodes> configCodes);





    ApprVehAcCondn eApprAcConToApprVehiAcCon(EApprVehAcCondn eApprVehAcCondn);
    EApprVehAcCondn apprVehiAcCondToEApprVehiAcCon(ApprVehAcCondn apprVehAcCondn);

    ApprVehInterCondn eApprVehiInteConToApprVehiInterCon (EApprVehInteriCondn eApprVehInteriCondn);
    EApprVehInteriCondn apprVehiInteCondToEApprVehiInteCondi(ApprVehInterCondn apprVehInterCondn);


    ApprVehOilCondn eApprOilCondToApprOilCon(EApprVehOilCondn eApprVehOilCondn);
    EApprVehOilCondn apprOilConToEApprOilCon(ApprVehOilCondn apprVehOilCondn);

    ApprVehStereoSts eApprSterStatusToApprSterStatus(EApprVehStereoSts eApprVehStereoSts);
    EApprVehStereoSts apprSterStatusToEApprSterStatus(ApprVehStereoSts apprVehStereoSts);

    ApprVehTireCondn eApprTireConToApprTireCon (EApprVehTireCondn eApprVehTireCondn);
    EApprVehTireCondn apprTireConToEApprTireCond(ApprVehTireCondn apprVehTireCondn);

    EVehDrWarnLightSts vehWarLigStsToEvehDrWarLiSts (VehDrWarnLightSts vehDrWarnLightSts);
    VehDrWarnLightSts evehWarLigStsToVehDrWarLiSts(EVehDrWarnLightSts eVehDrWarnLightSts);

    ApprTestDRStsImg VehToDto(EAppraiseVehicle vehicle);



    EUserRegistration userRegisToEUserRegis(UserRegistration userRegistration);
    UserRegistration EUserRegisToUserRegis(EUserRegistration eUserRegistration);

    EDealerRegistration dealerRegToEdealerReg(DealerRegistration dealerRegistration);

    DealerRegistration EdealerRegToDealerReg(EDealerRegistration eDealerRegistration);





}
