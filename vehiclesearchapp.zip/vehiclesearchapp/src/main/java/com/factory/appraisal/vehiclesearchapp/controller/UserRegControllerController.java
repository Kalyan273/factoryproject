package com.factory.appraisal.vehiclesearchapp.controller;

import com.factory.appraisal.vehiclesearchapp.ExceptionHandle.Response;
import com.factory.appraisal.vehiclesearchapp.dto.UserRegistration;
import com.factory.appraisal.vehiclesearchapp.services.UserRegistrationServiceImpl;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;


@RestController
@RequestMapping("/save")
public class UserRegControllerController {


    @Autowired
    private UserRegistrationServiceImpl userRegistrationService;
    @ApiOperation(value = "Add users in database")

    @PostMapping("/user")
    public ResponseEntity<Response> userCreation(@RequestBody @Valid UserRegistration userRegistration, @RequestHeader("id")Long dealerId){
        String message=userRegistrationService.createUser(userRegistration,dealerId);
        Response response= new Response();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(message);
        return new ResponseEntity<>(response,HttpStatus.ACCEPTED);
    }
}
