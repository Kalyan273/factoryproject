package com.factory.appraisal.vehiclesearchapp.persistence.model;
/**
 * @author : YogeshKumarV,Rupesh Khade
 */


import com.factory.appraisal.vehiclesearchapp.constants.AppraisalConstants;
import lombok.*;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.AuditTable;
import org.hibernate.envers.Audited;


import javax.persistence.*;
import java.util.Date;

@Audited
@AuditTable(value = "CONFIG_CODES_AUD",schema = "FACTORY_AUD")
@Entity
@Table(name = "CONFIG_CODES",schema = "FACTORY_DB")
@DynamicUpdate
@DynamicInsert
@Getter
@Setter
@NoArgsConstructor

@GenericGenerator(name = AppraisalConstants.SEQUENCE_NAME,
        strategy = AppraisalConstants.CUSTOM_SEQUENCE_GENERATOR,
        parameters = {@Parameter(name = "sequence", value = "config_codes_seq")})
@AttributeOverride(name = "id", column = @Column(name = "CODE_ID"))
@AttributeOverride(name = "createdBy", column = @Column(name = "CREATED_BY"))
@AttributeOverride(name = "createdOn", column = @Column(name = "CREATED_ON"))
@AttributeOverride(name = "modifiedBy", column = @Column(name = "MODIFIED_BY"))
@AttributeOverride(name = "modifiedOn", column = @Column(name = "MODIFIED_ON"))
@AttributeOverride(name = "valid", column = @Column(name = "IS_ACTIVE"))
public class EConfigurationCodes extends TransactionEntity {

    private String codeType;
    private String shortCode;
    private String longCode;
    private String shortDescrip;

    public EConfigurationCodes(String codeType, String shortCode, String longCode, String shortDescription) {

        this.codeType = codeType;
        this.shortCode = shortCode;
        this.longCode = longCode;
        this.shortDescrip = shortDescription;
    }
}