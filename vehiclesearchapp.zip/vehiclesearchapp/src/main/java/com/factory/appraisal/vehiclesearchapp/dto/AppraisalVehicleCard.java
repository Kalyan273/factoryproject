package com.factory.appraisal.vehiclesearchapp.dto;

/**
 *
 * This is the Model class use for to send the data to UI
 *
 * @author Rupesh Khade
 */

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
@ApiModel(description = "Appraisal card details")
public class AppraisalVehicleCard {


    private Long id;
    @ApiModelProperty(notes = "Manufacturer name")
    private String vehicleMake ;
    private String  vehicleModel ;
    private double appraisedValue;
    private String createdBy;
    private Long vehicleYear;
    private ApprTestDRStsImg apprTestDrSts;


}
