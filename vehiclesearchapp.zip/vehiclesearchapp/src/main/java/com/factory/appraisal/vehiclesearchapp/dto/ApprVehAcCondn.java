package com.factory.appraisal.vehiclesearchapp.dto;
//@author:Rupesh khade

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotNull;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ApprVehAcCondn {


    @NotNull
    private Boolean coldAir;
    @NotNull
    private Boolean badDisplay;
    @NotNull
    private Boolean fadedDisOrBtn;
    @NotNull
    private Boolean fanSpeedMalfun;
    @NotNull
    private Boolean climateCtrlMalfun;
    @NotNull
    private Boolean hotOrWarmAir;
    @NotNull
    private Boolean notOperational;


}
