package com.factory.appraisal.vehiclesearchapp.dto;
//@author:Rupesh khade


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


import javax.validation.Valid;
import javax.validation.constraints.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ApprTestDrSts {

    @Valid
    private ApprVehAcCondn apprVehAcCondn;
    @Valid
    private ApprVehInterCondn apprVehInterCondn;
    @Valid
    private ApprVehOilCondn apprVehOilCondn;
    @Valid
    private ApprVehStereoSts apprVehStereoSts;
    @Valid
    private ApprVehTireCondn apprVehTireCondn;
    @Valid
    private VehDrWarnLightSts vehDrWarnLightSts;
    @Size(max = 50)
    private String optionalEquipment;
    @Size(max = 4)
    @NotNull
    private String  engineType;
    @Size(max = 10)
    @NotNull
    private String transmissionType;
    @Size(max = 5)
    @NotNull
    private String steeringFeelSts;
    @Size(max = 30)
    private String doorLocks;
    @Size(max = 17)
    private String  frLeftSideImage;
    @Size(max = 15)
    @NotNull
    private String leftfrWinSts;
    @Size(max = 15)
    @NotNull
    private String   frRightWinSts;
    @Size(max = 15)
    @NotNull
    private String  rearLeftWinSts;
    @Size(max = 15)
    @NotNull
    private String  rearRightWinSts;
    @Size(max = 17)
    @NotNull
    private String frRightImg;
    @Size(max = 17)
    @NotNull
    private String  rearLeftImg;
    @Size(max = 17)
    @NotNull
    private String rearRightImg;
    @Size(max = 30)
    @NotNull
    private String interiorType;
    @Size(max = 30)
    private String lightCondition;
    @Size(max = 50)
    private String roofType;
    @Size(max = 10)
    private String apprFollowUp;
    @Size(max = 10)
    private String apprInvenSts;
    @Size(max = 10)
    private String vehExtColor;
    @Size(max = 50)
    private String externalDmgSts;
    @Size(max = 50)
    private String frDrSideDmgSts;
    @Size(max = 50)
    private String frDrSideDmgTxtBox;
    private String frDrSideDmgPic;

    @Size(max = 50)
    private String frPassenSideDmgSts;
    @Size(max = 50)
    private String frPassenSideDmgTxtBox;
    private String frPassenSideDmgPic;


//     private String optionalEquipment;
    @Size(max = 50)
    private String frDrSidePntWrkSts;
    @Size(max = 50)
    private String frDrSidePntWrkTxtBox;
    private String frDrSidePntWrkPic;

    @Size(max = 50)
    private String frPassenSidePntWrk ;
   
    @Size(max = 50)
    private String frPassenSidePntWrkTxtBox;
    private String frPassenSidePntWrkPic;
    @Size(max = 50)
    private String rearDrSidePntWrk;
    @Size(max = 50)
    private String rearDrSidePntWrkTxtBox;
    private String rearDrSidePntWrkPic;
    @Size(max = 50)
    private String rearPassenSidePntWrk;
    @Size(max = 50)
    private String rearPassenSidePntWrkTxtBox;
    private String rearPassenSidePntWrkPic;
    @Size(max = 50)
    private String paintWork;

    @Size(max = 50)
    private String rearDrSideDmgSts;
    @Size(max = 50)
    private String rearDrSideDmgTxtBox;

    private String rearDrSideDmgPic;
    @Size(max = 50)
    private String rearPassenSideDmgSts;

    @Size(max = 50)
    private String rearPassenSideDmgTxtBox;
    private String rearPassenSideDmgPic;

    
   
    @Size(max = 50)
    private String WholeBuyFigsStatus;
    @Size(max = 50)
    private String frWindshieldDmg;


    private String quickAppraisal;

    private String vehicleMileage;

    private String vehicleInterior;


    private String keyAssureYes;
    private String subscribToKeyAssure;
    private String keyAssureFiles;
    private String brakingSysSts;

    private String booksAndKeys;
    private String titleSts;

    private String adjustedWholePoor;
    private String adjustedWholeFair;
    private String adjustedWholeGood;
    private String adjustedWholeVeryGood;
    private String adjustedWholeExcelnt;
    private String adjustedFinanPoor;
    private String adjustedFinanFair;
    private  String adjustedFinanGood;
    private String adjustedFinanVeryGood;
    private String adjustedFinanExcelnt;
    private String adjustedRetailPoor;
    private  String adjustedRetailFair;
    private String adjustedRetailGood;
    private String adjustedRetailVeryGood;
    private String adjustedRetailExcelnt;

    private String pushForBuyFig;

    private String dealerReserve;
    private String comsumerAskPrice;
    private String delrRetlAskPrice;



    private String vehiclePic1;
    private String vehiclePic2;
    private String vehiclePic3;
    private String vehiclePic4;
    private String vehiclePic5;
    private String vehiclePic6;
    private String vehiclePic7;
    private String vehiclePic8;
    private String vehiclePic9;
    private String vehicleVideo1;

    private String profOpinion;
    private String vehicleDesc;

    private String  rearGlassDmg;
    private String vehicleExtColor;


}
