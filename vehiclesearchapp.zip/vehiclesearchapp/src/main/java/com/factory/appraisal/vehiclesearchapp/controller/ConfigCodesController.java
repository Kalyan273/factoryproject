package com.factory.appraisal.vehiclesearchapp.controller;

import com.factory.appraisal.vehiclesearchapp.dto.ConfigCodes;
import com.factory.appraisal.vehiclesearchapp.responseHandler.ApiResponseHandler;
import com.factory.appraisal.vehiclesearchapp.services.ConfigurationCodesService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/congifcodes")
@Api(tags = "Configcodes", value = "operation on configCode")

public class ConfigCodesController {
    @Autowired
    private ConfigurationCodesService configurationCodesService;

    @ApiOperation(value = "Add Config Codes in Database")
    @PostMapping("/addConfigCode")
    public ResponseEntity<Object> postConfigurationCodes(@RequestBody List<ConfigCodes> configCodes){
        String s = configurationCodesService.addConfigCode(configCodes);

        return ApiResponseHandler.generateResponse(HttpStatus.OK,s);


    }




  /*  @GetMapping("/showall/{pageNumber}/{pageSize}")
    public ResponseEntity<List<ConfigurationCodes>> showAllConfigurationCodes(@PathVariable Integer pageNumber,@PathVariable Integer pageSize){
        return new ResponseEntity<>(configurationCodesService.GetConfigCodes(pageNumber,pageSize),
                HttpStatus.OK
        );
    }
    @PutMapping("/update/{codeId}")
    public ResponseEntity<ConfigurationCodes> changeEConfigurationCodes(@PathVariable long codeId, @RequestBody @Valid ConfigurationCodes configurationCodes){
        return new ResponseEntity<>(configurationCodesService.updateConfigCodes(codeId,configurationCodes),
                HttpStatus.ACCEPTED
        );
    }
    @DeleteMapping("/delete/{codeId}")
    public ResponseEntity<String> deleteEConfigurationCode(@PathVariable long codeId){
        return new ResponseEntity<>(configurationCodesService.deleteConfigCodes(codeId),
                HttpStatus.OK
        );
    }*/
}
