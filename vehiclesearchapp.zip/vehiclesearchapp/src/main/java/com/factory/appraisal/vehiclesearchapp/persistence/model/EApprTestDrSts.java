package com.factory.appraisal.vehiclesearchapp.persistence.model;

/**
 * @author Rupesh Khade
 */


import com.factory.appraisal.vehiclesearchapp.constants.AppraisalConstants;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import org.hibernate.envers.AuditTable;
import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import javax.persistence.*;

@Audited
@Entity
@AuditTable(value = "APR_TEST_DR_STATUS_AUD", schema = "FACTORY_AUD")

@Table(name = "APR_TEST_DR_STATUS",schema = "FACTORY_DB")
@Getter
@Setter
@NoArgsConstructor
@DynamicUpdate
@DynamicInsert
@AttributeOverride(name = "id", column = @Column(name = "VEH_STATUS_ID"))
@AttributeOverride(name = "valid",column= @Column(name = "IS_ACTIVE"))
@AttributeOverride(name="createdBy",column =@Column(name = "CREATED_BY"))
@AttributeOverride(name="createdOn",column =@Column(name = "CREATED_ON"))
@AttributeOverride(name=" modifiedBy",column =@Column(name = "MODIFIED_BY"))
@AttributeOverride(name="modifiedOn",column =@Column(name = "MODIFIED_ON"))

@GenericGenerator(name = AppraisalConstants.SEQUENCE_NAME, strategy = AppraisalConstants.CUSTOM_SEQUENCE_GENERATOR,parameters = {@Parameter(name = "sequence", value = "APR_TEST_DR_STATUS_SEQ")})

public class EApprTestDrSts extends TransactionEntity {

    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    @OneToOne(targetEntity = EAppraiseVehicle.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "APPRAISAL_REF ", referencedColumnName = "APPR_REF_ID", nullable = false)
    private EAppraiseVehicle appraisalRef;

    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    @OneToOne(mappedBy = "vehicleStatus", cascade = CascadeType.ALL)
    private EApprVehAcCondn apprVehAcCondn;

    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    @OneToOne(mappedBy = "vehicleStatus", cascade = CascadeType.ALL)
    private EApprVehInteriCondn apprVehInteriCondn;
    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    @OneToOne(mappedBy = "vehicleStatus", cascade = CascadeType.ALL)
    private EApprVehOilCondn apprVehOilCondn;

    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    @OneToOne(mappedBy = "vehicleStatus", cascade = CascadeType.ALL)
    private EApprVehStereoSts apprVehStereoSts;

    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    @OneToOne(mappedBy = "vehicleStatus", cascade = CascadeType.ALL)
    private EApprVehTireCondn apprVehTireCondn;

    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    @OneToOne(mappedBy = "vehicleStatus", cascade = CascadeType.ALL)
    private EVehDrWarnLightSts vehDrWarnLightSts;


    @Column(name = "OPT_EQUIPMENT")
    private String optionalEquipment;   //this maybe a table
    @Column(name = "ENGINE_TYPE")
    private String engineType;
    @Column(name = "TRANSMISSION_TYPE ")
    private String transmissionType;
    @Column(name = " STEERING")
    private String steeringFeelSts;
    @Column(name = "DR_LOCK_TYPE")
    private String doorLocks;
    @Column(name = "F_L_IMAGE")
    private String frLeftSideImage;
    @Column(name = "F_L_WIN_STATUS ")
    private String leftfrWinSts;
    @Column(name = "F_R_WIN_STATUS")
    private String frRightWinSts;
    @Column(name = "R_L_WIN_STATUS ")
    private String rearLeftWinSts;
    @Column(name = "R_R_WIN_STATUS")
    private String rearRightWinSts;
    @Column(name = "F_R_IMAGE")
    private String frRightImg;
    @Column(name = "R_L_IMAGE")
    private String rearLeftImg;
    @Column(name = "R_R_IMAGE")
    private String rearRightImg;
    @Column(name = "INTR_TYPE")
    private String interiorType;
    @Column(name = "LIGHT_CONDN ")
    private String lightCondition;
    @Column(name = "ROOF_TYPE")
    private String roofType;
    @Column(name = "APR_FOLLOW_UP ")
    private String apprFollowUp;
    @Column(name = "APR_INV_STATUS ")
    private String apprInvenSts;
    @Column(name = "EXTR_COLOR")
    private String vehExtColor;
    @Column(name = "EXTR_DMG_STATUS ")
    private String externalDmgSts;
    @Column(name = "F_DR_SIDE_DMG_STS")
    private String frDrSideDmgSts;
    @Column(name = "F_DR_SIDE_DMG_DESC")
    private String frDrSideDmgTxtBox;

    private String frDrSideDmgPic;

    @Column(name = "F_P_SIDE_DMG_STS ")
    private String frPassenSideDmgSts;
    @Column(name = "F_P_SIDE_DMG_DESC")
    private String frPassenSideDmgTxtBox;
    private String frPassenSideDmgPic;


    @Column(name = "PNTWRK_FD_SIDE_STS ")
    private String frDrSidePntWrkSts;
    @Column(name = "PNTWRK_FD_SIDE_STS_DESC")
    private String frDrSidePntWrkTxtBox;
    private String frDrSidePntWrkPic;

    @Column(name = "PNTWRK_FP_SIDE_STS")
    private String frPassenSidePntWrk ;
    @Column(name = "PNTWRK_FP_SIDE_STS_DESC")
    private String frPassenSidePntWrkTxtBox;
    private String frPassenSidePntWrkPic;
    @Column(name = "PNTWRK_RD_SIDE_STS")
    private String rearDrSidePntWrk;
    @Column(name = "PNTWRK_RD_SIDE_STS_DESC")
    private String rearDrSidePntWrkTxtBox;
    private String rearDrSidePntWrkPic;

    @Column(name = "PNTWRK_RP_SIDE_STS")
    private String rearPassenSidePntWrk;
    @Column(name = "PNTWRK_RP_SIDE_STS_DESC")
    private String rearPassenSidePntWrkTxtBox;
    private String rearPassenSidePntWrkPic;
    @Column(name = "PNTWRK_STATUS")

    private String paintWork;

    @Column(name = "R_DR_SIDE_DMG_STS ")
    private String rearDrSideDmgSts;
    @Column(name = "R_DR_SIDE_DMG_DESC")
    private String rearDrSideDmgTxtBox;
    private String rearDrSideDmgPic;

    @Column(name = "R_PASS_SIDE_DMG_STS ")
    private String rearPassenSideDmgSts;
    @Column(name = "R_PASS_SIDE_DMG_DESC")
    private String rearPassenSideDmgTxtBox;
    private String rearPassenSideDmgPic;

    @Column(name = "WS_BUY_FIG_STS ")
    private String WholeBuyFigsStatus;
    @Column(name = "WIND_SHIELD_DMG")
    private String frWindshieldDmg;


    @Column(name = "QUIK_APPRAISAL")
    String quickAppraisal;
    @Column(name = "VECLE_MILEAGE")
    private String vehicleMileage;
    
    private String vehicleInterior;
    @Column(name = "KEY_ASSUR_YES")
    private String keyAssureYes;

    @Column(name = "SUBSCB_TO_KEY_ASSURE")
    private String subscribToKeyAssure;

    @Column(name = "KEY_ASSUR_FILE")
    private String keyAssureFiles;
    @Column(name = "BRAKE_SYS_STATS")
    private String brakingSysSts;
    @Column(name = "BOOKS_AND_KEYS")
    private String booksAndKeys;
    @Column(name = "TITL_STATS")
    private  String titleSts;

    @Column(name = "ADJS_WHOLE_POOR")
    private  String adjustedWholePoor;
    @Column(name = "ADJS_WHOLE_SALE_FAIR")
    private  String adjustedWholeFair;
    @Column(name = "ADJS_WHOLE_SALE_GOOD")
    private String adjustedWholeGood;
    @Column(name = "ADJS_WHOLE_SALE_VERY_GOOD")
    private  String adjustedWholeVeryGood;
    @Column(name = "ADJS_WHOLE_SALE_EXCELNT")
    private  String adjustedWholeExcelnt;
    @Column(name = "ADJS_FINAN_POOR")
    private  String adjustedFinanPoor;
    @Column(name = "ADJS_FINAN_FAIR")
    private  String adjustedFinanFair;
    @Column(name = "ADJS_FINAN_GOOD")
    private  String adjustedFinanGood;
    @Column(name = "ADJS_FINAN_VERY_GOOD")
    private  String adjustedFinanVeryGood;
    @Column(name = "ADJS_FINAN_EXCLNT")
    private  String adjustedFinanExcelnt;
    @Column(name = "ADJS_RETL_POOR")
    private String adjustedRetailPoor;
    @Column(name = "ADJS_RETL_FAIR")
    private String adjustedRetailFair;
    @Column(name = "ADJS_RETL_GOOD")
    private String adjustedRetailGood;
    @Column(name = "ADJS_RETL_VRY_GOOD")
    private  String adjustedRetailVeryGood;

    @Column(name = "ADJS_RETL_EXCLNT")
    private  String adjustedRetailExcelnt;
    @Column(name = "PUSH_FOR_BUY_FIG")
    private String pushForBuyFig;
    @Column(name = "DEALR_RESRV")
    private String dealerReserve;
    @Column(name = "CONSMR_ASK_PRIC")
    private String comsumerAskPrice;
    @Column(name = "DELR_RETL_ASK_PRIC")
    private String delrRetlAskPrice;

    //Pic

    private String vehiclePic1;
    private String vehiclePic2;
    private String vehiclePic3;
    private String vehiclePic4;
    private String vehiclePic5;
    private String vehiclePic6;
    private String vehiclePic7;
    private String vehiclePic8;
    private String vehiclePic9;
    private String vehicleVideo1;

    private String profOpinion;

    private String vehicleDesc;


    private String  rearGlassDmg;

    private String vehicleExtColor;

   


}