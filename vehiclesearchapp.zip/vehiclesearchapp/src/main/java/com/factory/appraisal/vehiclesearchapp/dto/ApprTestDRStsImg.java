package com.factory.appraisal.vehiclesearchapp.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ApprTestDRStsImg {

    private String vehiclePic1;


}
