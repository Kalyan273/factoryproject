package com.factory.appraisal.vehiclesearchapp.persistence.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.*;
import org.springframework.format.annotation.DateTimeFormat;


import javax.persistence.Inheritance;
import javax.persistence.MappedSuperclass;
import java.util.Date;


@MappedSuperclass
@Inheritance
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter

public class TransactionEntity extends IdEntity {

    @CreatedBy
    private String createdBy;

    @CreatedDate
    @DateTimeFormat(pattern = "MM/dd/yyyy HH:mm:ss")
    private Date createdOn;


    @LastModifiedBy
    private String modifiedBy;

    @LastModifiedDate
    @DateTimeFormat(pattern = "MM/dd/yyyy HH:mm:ss")
    private Date modifiedOn;


}
