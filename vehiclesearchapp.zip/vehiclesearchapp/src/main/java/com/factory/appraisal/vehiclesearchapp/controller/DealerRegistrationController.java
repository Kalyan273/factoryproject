package com.factory.appraisal.vehiclesearchapp.controller;


import com.factory.appraisal.vehiclesearchapp.ExceptionHandle.Response;
import com.factory.appraisal.vehiclesearchapp.dto.DealerRegistration;
import com.factory.appraisal.vehiclesearchapp.services.DealerRegistrationService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
@RequestMapping("/saveDealer")
public class DealerRegistrationController {

    @Autowired
    private DealerRegistrationService dealerRegistrationService;
    @ApiOperation(value = "Add dealer in database")

    @PostMapping("/dealer")
    public ResponseEntity<Response> dealerCreation(@RequestBody @Valid DealerRegistration dealerRegistration){
        String message=dealerRegistrationService.createDealer(dealerRegistration);
        Response response= new Response();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(message);
        return new ResponseEntity<>(response,HttpStatus.ACCEPTED);
    }
}
