package com.factory.appraisal.vehiclesearchapp.dto;

import com.factory.appraisal.vehiclesearchapp.ExceptionHandle.Response;
import lombok.*;

import java.util.List;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class ApprCreaPage extends Response {

    //AppraiseVehicle
    private String clientFirstName;
    private String clientLastName;
    private String clientPhNum;
    private String dealershipUserNames;

    //AppraisalVehicle
    private String vinNumber;
    private Long vehicleYear;
    private String vehicleMake;
    //AppraisalVehicle
    private String vehicleModel;
    //AppraisalVehicle
    private String vehicleSeries;

//testDrivests
    private String vehicleMileage;
    //AppraisalTestDriveSts
    private String engineType;
    private String transmissionType;

    //Test Drive Sts
    private String vehicleExtColor;

    private String vehicleInterior;

    //VehicleDrivingWarnLightSts
    private List<String> dashWarningLights;

    //AppraisalVehicleAcCondition
    private List<String> acCondition;

    //AppraisalTestDriveSts
    private String doorLocks;
    private String roofType;

    //AppraisalVehicleStereoSts
    private List<String> stereoSts;
    private List<String> interiorCondn;

    //AppraisalTestDriveSts
    private String leftfrWinSts;
    private String frRightWinSts;
    private String rearLeftWinSts;
    private String rearRightWinSts;

    //
    private String quickAppraisal;

    //Pic
    private String vehiclePic1;
    private String vehiclePic2;
    private String vehiclePic3;
    private String vehiclePic4;
    private String vehiclePic5;
    private String vehiclePic6;
    private String vehiclePic7;
    private String vehiclePic8;
    private String vehiclePic9;
    private String vehicleVideo1;

    //AppraisalVehicleOilCondition
    private List<String> oilCondition;

    //Appraisal test Drive Sts
    private String externalDmgSts;

    //AppraisalTestDriveSts
    private String frDrSideDmgSts;
    private String frDrSideDmgTxtBox;
    private String frDrSideDmgPic;
    
    private String rearDrSideDmgSts;
    private String rearDrSideDmgTxtBox;
    private String rearDrSideDmgPic;
    
    private String rearPassenSideDmgSts;
    private String rearPassenSideDmgTxtBox;
    private String rearPassenSideDmgPic;
    
    private String frPassenSideDmgSts;
    private String frPassenSideDmgTxtBox;
    private String frPassenSideDmgPic;
    
    private String paintWork;
    private String frDrSidePntWrkSts;
    private String frDrSidePntWrkTxtBox;
    private String frDrSidePntWrkPic;
    
    
    private String rearDrSidePntWrk;
    private String rearDrSidePntWrkTxtBox;
    private String rearDrSidePntWrkPic;
    
    
    private String rearPassenSidePntWrk;
    private String rearPassenSidePntWrkTxtBox;
    private String rearPassenSidePntWrkPic;
    
    private String frPassenSidePntWrk;
    private String frPassenSidePntWrkTxtBox;
    private String frPassenSidePntWrkPic;


    private String frWindshieldDmg;
    private String rearGlassDmg;


    private String keyAssureYes;
    private String subscribToKeyAssure;
    private String keyAssureFiles;
    private String  brakingSysSts;

    //Appraisal vehicle
    private String enginePerfor;
    private String transmiSts;

    //AppraisalTest Drive Sts
    private String steeringFeelSts;


    private String booksAndKeys;
    private String titleSts;

    private String profOpinion;
    //ConfigurationCodes
    private String vehicleDesc;


    //SignDet
    private String eSign;

    //EAppraisalTestDriveSts at present later we will shift to esign
    private String adjustedWholePoor;
    private String adjustedWholeFair;
    private String adjustedWholeGood;
    private String adjustedWholeVeryGood;
    private String adjustedWholeExcelnt;
    private String adjustedFinanPoor;
    private String adjustedFinanFair;
    private String adjustedFinanGood;
    private String adjustedFinanVeryGood;
    private String adjustedFinanExcelnt;
    private String adjustedRetailPoor;
    private String adjustedRetailFair;
    private String adjustedRetailGood;
    private String adjustedRetailVeryGood;
    private String adjustedRetailExcelnt;

    //AppraisalVehicle
    private double appraisedValue;


    private String dealerReserve;
    private String comsumerAskPrice;
    private String delrRetlAskPrice;


    private String pushForBuyFig;




}
