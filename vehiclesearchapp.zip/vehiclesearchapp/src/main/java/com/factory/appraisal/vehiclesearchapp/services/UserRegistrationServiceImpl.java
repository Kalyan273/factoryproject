package com.factory.appraisal.vehiclesearchapp.services;


/**
 * This class is implementing the methods of UserRegistrationService
 * this is the service class for user registration
 */

import com.factory.appraisal.vehiclesearchapp.controller.UserRegControllerController;
import com.factory.appraisal.vehiclesearchapp.dto.UserRegistration;
import com.factory.appraisal.vehiclesearchapp.persistence.mapper.AppraisalVehicleMapper;
import com.factory.appraisal.vehiclesearchapp.persistence.model.EDealerRegistration;
import com.factory.appraisal.vehiclesearchapp.persistence.model.ERole;
import com.factory.appraisal.vehiclesearchapp.persistence.model.EUserRegistration;
import com.factory.appraisal.vehiclesearchapp.repository.DealerRegistrationRepo;
import com.factory.appraisal.vehiclesearchapp.repository.RoleRepo;
import com.factory.appraisal.vehiclesearchapp.repository.UserRegistrationRepo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserRegistrationServiceImpl implements UserRegistrationService {

    Logger log = LoggerFactory.getLogger(UserRegControllerController.class);
    @Autowired
    UserRegistrationRepo userRegistrationRepo;
    @Autowired
    DealerRegistrationRepo dealerRegistrationRepo;
    @Autowired
    RoleRepo roleRepo;

    @Autowired
    private AppraisalVehicleMapper appraisalVehicleMapper;

    /**
     * createUser method is taking the userRegistration object and dealerId as input
     * and creating user
     * @param userRegistration
     * @param dealerId
     * @return
     */


    @Override
    public String createUser(UserRegistration userRegistration, Long dealerId) {
        EUserRegistration eUserRegistration = appraisalVehicleMapper.userRegisToEUserRegis(userRegistration);
        try {
            EDealerRegistration eDealerRegistration = dealerRegistrationRepo.findById(dealerId).orElse(null);
            if (null != eDealerRegistration) {
                eUserRegistration.setDealer(eDealerRegistration);
                ERole role = roleRepo.findByRole("user");
//                ERole erole = new ERole();
//                erole.setRole("user");
                eUserRegistration.setRole(role);
                EUserRegistration save = userRegistrationRepo.save(eUserRegistration);
                UserRegistration userRegistration1 = appraisalVehicleMapper.EUserRegisToUserRegis(save);
                return "User Has Been saved Successfully";
            } else throw new RuntimeException("invalid dealerId");

        } catch (RuntimeException e) {
            throw new RuntimeException(e.getMessage());
        }
    }
}
