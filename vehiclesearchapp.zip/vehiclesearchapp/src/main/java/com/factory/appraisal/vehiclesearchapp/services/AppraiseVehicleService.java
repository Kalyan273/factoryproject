package com.factory.appraisal.vehiclesearchapp.services;

import com.factory.appraisal.vehiclesearchapp.ExceptionHandle.Response;
import com.factory.appraisal.vehiclesearchapp.dto.ApprCreaPage;
import com.factory.appraisal.vehiclesearchapp.dto.VideoResponse;
import org.springframework.web.multipart.MultipartFile;

public interface AppraiseVehicleService {


    /**
     *
     * @param apprCreaPage
     * the dto class having fields which store values in respective classes
     * @return status of adding appraisal saved or not
     * @Author yudhister
     */
    String addAppraiseVehicle(ApprCreaPage apprCreaPage, Long userId) ;



    /**
     *
     * @param userId this is the user id
     * @param pageNumber this is the page number
     * @param pageSize this is the number of cards per page
     * @return Appraisal card list and page information ie total records and  total pages
     * @author Rupesh khade
     *
     */
    Response findAllCards(Long userId, Integer pageNumber, Integer pageSize);

    /**
     *
     * @param imageName This is the image name
     * @return image of a car
     * @author Rupesh Khade
     *
     */
    byte[]  downloadImageFromFileSystem(String imageName);

    /**
     * This method is uploading the image and storing in local folder
     * @param file
     * @return file name OR Image name
     * @author kalyan
     */
    String imageUpload(MultipartFile file);

    /**
     *
     * @param AppraisalId
     * @return edit page
     * @autor kalyan
     */
    Response showInEditPage(Long AppraisalId);
    /**
     * This method uploads the video file in local folder
     * @author Rupesh Khade
     * @param file
     * @return name of video with uuid
     */
    String videoUpload(MultipartFile file);

    /**
     *This method sends video file
     * @author Rupesh khade
     * @param videoName
     * @return video file as attachment
     */
    VideoResponse videoDownload(String videoName);

    /**
     * This method Updates the Appraisal
     * @param page
     * @param apprId
     * @return
     * @author Kalyan
     */
    public Response updateAppraisal(ApprCreaPage page, Long apprId);


    Response deleteAppraisalVehicle(Long apprRef);









}
