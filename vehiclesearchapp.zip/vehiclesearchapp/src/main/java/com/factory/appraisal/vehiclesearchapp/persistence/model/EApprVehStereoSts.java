package com.factory.appraisal.vehiclesearchapp.persistence.model;


//kalyan
import com.factory.appraisal.vehiclesearchapp.constants.AppraisalConstants;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.envers.AuditTable;
import org.hibernate.annotations.Parameter;
import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import javax.persistence.*;

@Audited
@AuditTable(value = "APR_VEH_STEREO_STATUS_AUD",schema = "FACTORY_AUD")
@Table(name="APR_VEH_STEREO_STATUS",schema = "FACTORY_DB")
@DynamicUpdate
@DynamicInsert
@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@GenericGenerator(name = AppraisalConstants.SEQUENCE_NAME,
        strategy = AppraisalConstants.CUSTOM_SEQUENCE_GENERATOR,
        parameters = {@Parameter(name = "sequence", value = "APR_VEH_STEREO_STATUS_SEQ")})

@AttributeOverride(name = "id", column = @Column(name = "STEREO_ST_ID"))
@AttributeOverride(name = "createdBy", column = @Column(name = "CREATED_BY"))
@AttributeOverride(name = "createdOn", column = @Column(name = "CREATED_ON"))
@AttributeOverride(name = "modifiedBy", column = @Column(name = "MODIFIED_BY"))
@AttributeOverride(name = "modifiedOn", column = @Column(name = "MODIFIED_ON"))
@AttributeOverride(name = "valid", column = @Column(name = "IS_ACTIVE"))
public class EApprVehStereoSts extends TransactionEntity {


    @Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    @OneToOne(targetEntity = EApprTestDrSts.class,fetch = FetchType.LAZY,cascade = CascadeType.ALL)
    @JoinColumn(name = "VEH_STATUS_ID",referencedColumnName = "VEH_STATUS_ID",nullable = false)
    private EApprTestDrSts vehicleStatus;

    @Column(name = "FACTORY_EQU_OP")
    private boolean factoryEquptOperat ;
    @Column(name = "EQPT_NOT_OP")
    private boolean factoryEquptNotOperat ;
    @Column(name = "KNOBS_MISSING")
    private boolean knobsMissing ;
    @Column(name = "AFT_MKT_NAV_NICE_SYS")
    private boolean aftMktNavigaNiceSys;
    @Column(name = "AFT_MKT")
    private boolean afterMarket;
    @Column(name = "AFT_MKT_R_ENTMT_SYS")
    private boolean aftMktRearEntertainSys ;
    @Column(name = "FACTORY_R_ENTMT_SYS")
    private boolean factoryRearEntertainSys ;
    @Column(name = "PRO_INSTALL")
    private boolean profInstall ;
    @Column(name = "BROKEN_SCREEN")
    private boolean brokenScreen ;
    @Column(name = "FADED_DIS_OR_BTNS")
    private boolean fadedDisBtn;
    @Column(name = "NOT_OPRNL")
    private boolean notOperational ;
    @Column(name = "OPERATIONAL")
    private boolean operational ;

}