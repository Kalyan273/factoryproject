package com.factory.appraisal.vehiclesearchapp.services;

import com.factory.appraisal.vehiclesearchapp.dto.UserRegistration;

public interface UserRegistrationService {
    /**
     *this method will create user
     * Method taking UserRegistration as argument and returning a message
     *
     * @param userRegistration
     * @return
     */

    String createUser(UserRegistration userRegistration,Long dealerId);
}
