package com.factory.appraisal.vehiclesearchapp.services;
//Author:Rupesh khade,yogesh,kalyan,vijay


import com.factory.appraisal.vehiclesearchapp.ExceptionHandle.Response;
import com.factory.appraisal.vehiclesearchapp.constants.AppraisalConstants;
import com.factory.appraisal.vehiclesearchapp.dto.ApprCreaPage;
import com.factory.appraisal.vehiclesearchapp.dto.AppraisalVehicleCard;
import com.factory.appraisal.vehiclesearchapp.dto.CardsPage;

import com.factory.appraisal.vehiclesearchapp.dto.VideoResponse;
import com.factory.appraisal.vehiclesearchapp.persistence.mapper.*;
import com.factory.appraisal.vehiclesearchapp.persistence.model.*;
import com.factory.appraisal.vehiclesearchapp.repository.*;
import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

@Service
public class AppraiseVehicleServiceImpl implements AppraiseVehicleService {

    Logger log = LoggerFactory.getLogger(AppraiseVehicleServiceImpl.class);

    @Autowired
    private AppraiseVehicleRepo eAppraiseVehicleRepo;
    @Autowired
    private SignDetRepo signDetRepo;
    @Autowired
    private DealerRegistrationRepo dealerRepo;
    @Autowired

    private UserRegistrationRepo userRegistrationRepo;
    @Autowired
    ApprTestDrStsRepo eApprTestDrStsRepo;
    @Autowired
    private AppraisalVehicleMapper appraisalVehicleMapper;
    @Autowired
    private ApprVehAcCondnRepo acConditionRepo;
    @Autowired
    private ApprVehTireCondnRepo tireConditionRepo;
    @Autowired
    private VehDrWarnLightStsRepo warnLightStatusRepo;
    @Autowired
    private ApprVehStereoStsRepo stereoStatusRepo;
    @Autowired
    private ApprVehOilCondnRepo oilConditionRepo;
    @Autowired
    private ApprVehInteriCondnRepo interiorConditionRepo;
    @Autowired
    private ConfigurationCodesRepo configurationCodesRepo;




    @Override
    public String addAppraiseVehicle(ApprCreaPage apprCreaPage, Long userId) {


        EAppraiseVehicle eAppraiseVehicle = appraisalVehicleMapper.AppCreaPageToEAppVehCond(apprCreaPage);


        eAppraiseVehicle.setDealer(userRegistrationRepo.getOne(userId).getDealer());
        eAppraiseVehicle.setUser(userRegistrationRepo.getOne(userId));
        eAppraiseVehicle.setCreatedOn(new Date());

        List<String> acCond = apprCreaPage.getAcCondition();

        EApprVehAcCondn eAcCondition = AddApprSetACCond(acCond);

        List<String> warnLightSts = apprCreaPage.getDashWarningLights();

        EVehDrWarnLightSts eWarnLightStatus = AddApprSetVehWarnLightCond(warnLightSts);


        List<String> vehStereoSts = apprCreaPage.getStereoSts();
        EApprVehStereoSts eStereoStatus = AddApprSetApprVehStereoSts(vehStereoSts);

        List<String> vehIntCond = apprCreaPage.getInteriorCondn();

        EApprVehInteriCondn eInteriorCondition = AddApprSetVehInteriorCond(vehIntCond);


        List<String> vehOilCond = apprCreaPage.getOilCondition();
        EApprVehOilCondn eOilCond = AddApprSetVehOilCond(vehOilCond);


        EApprTestDrSts eApprTestDrSts = appraisalVehicleMapper.AppCreaPageToEAppTestDrSts(apprCreaPage);
            eAcCondition.setVehicleStatus(eApprTestDrSts);
            eWarnLightStatus.setVehicleStatus(eApprTestDrSts);
            eStereoStatus.setVehicleStatus(eApprTestDrSts);
            eInteriorCondition.setVehicleStatus(eApprTestDrSts);
            eOilCond.setVehicleStatus(eApprTestDrSts);

            eApprTestDrSts.setApprVehAcCondn(eAcCondition);
            eApprTestDrSts.setVehDrWarnLightSts(eWarnLightStatus);
            eApprTestDrSts.setApprVehStereoSts(eStereoStatus);
            eApprTestDrSts.setApprVehOilCondn(eOilCond);
            eApprTestDrSts.setApprVehInteriCondn(eInteriorCondition);
            eApprTestDrSts.setAppraisalRef(eAppraiseVehicle);
            
            eAppraiseVehicle.setApprTestDrSts(eApprTestDrSts);


            eAppraiseVehicle.setValid(true);

            eAppraiseVehicleRepo.save(eAppraiseVehicle);//4

            return "saved successfully";


        }




    @Override
    public Response  findAllCards(Long userId, Integer pageNumber, Integer pageSize)  {

        CardsPage pageInfo = new CardsPage();
        try{
            Pageable pageable = PageRequest.of(pageNumber, pageSize, Sort.by("createdOn").descending());

            Page<EAppraiseVehicle> pageResult = eAppraiseVehicleRepo.findAllByValidIsTrueAndUserIdOrderByCreatedOnDesc(userId, pageable);

            if(pageResult.getTotalElements()!=0) {

                pageInfo.setTotalRecords(pageResult.getTotalElements());
                pageInfo.setTotalPages(pageResult.getTotalPages());

                List<EAppraiseVehicle> apv = pageResult.toList();
                List<AppraisalVehicleCard> appraiseVehicleDtos = appraisalVehicleMapper.lEApprVehiToLApprVehiCard(apv);
                pageInfo.setCards(appraiseVehicleDtos);
            }
            else throw new RuntimeException("AppraisalCards not available");
        }
        catch (RuntimeException ex){
            Response response=new Response();
            response.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
            response.setMessage(ex.getMessage());
            return response;
        }
        return pageInfo;

    }

    @Override
    public byte[] downloadImageFromFileSystem(String imageName)  {
        byte[] images=null;

        String filePath = AppraisalConstants.IMAGE_FOLDER_PATH + imageName;
        try {
            images = Files.readAllBytes(new File(filePath).toPath());//Reading from folder


        }catch (IOException e){
            log.error(e.getMessage());
        }

        return images;
    }



    @Override
    public String imageUpload(MultipartFile file) {


        String extension = FilenameUtils.getExtension(file.getOriginalFilename());
        String filename = UUID.randomUUID().toString() + "." + extension;
        Path filePath = Paths.get(AppraisalConstants.IMAGE_FOLDER_PATH + filename);
        try{ Files.write(filePath, file.getBytes());
        }
        catch (IOException exception){
            log.error(exception.getMessage());
        }
        return filename;
    }


    public Response showInEditPage(Long AppraisalId) {

        ApprCreaPage apprCrePg = new ApprCreaPage();

        try {

            EAppraiseVehicle eAppraiseVehicles = eAppraiseVehicleRepo.findById(AppraisalId).orElse(null);


            if (null != eAppraiseVehicles) {


                EApprTestDrSts apprTstDriSts = eAppraiseVehicles.getApprTestDrSts();
                EApprVehInteriCondn apprVehIntCon = eAppraiseVehicles.getApprTestDrSts().getApprVehInteriCondn();
                EApprVehStereoSts apprVehSteSts = eAppraiseVehicles.getApprTestDrSts().getApprVehStereoSts();
                EApprVehOilCondn apprVehOlCond = eAppraiseVehicles.getApprTestDrSts().getApprVehOilCondn();
                EApprVehAcCondn apprVehAcCon = eAppraiseVehicles.getApprTestDrSts().getApprVehAcCondn();
                EVehDrWarnLightSts appVehDriWarnLight = eAppraiseVehicles.getApprTestDrSts().getVehDrWarnLightSts();

                apprCrePg.setClientFirstName(eAppraiseVehicles.getClientFirstName());
                apprCrePg.setClientLastName(eAppraiseVehicles.getClientLastName());
                apprCrePg.setClientPhNum(eAppraiseVehicles.getClientPhNum());
                apprCrePg.setVinNumber(eAppraiseVehicles.getVinNumber());
                apprCrePg.setVehicleYear(eAppraiseVehicles.getVehicleYear());
                apprCrePg.setVehicleMake(eAppraiseVehicles.getVehicleMake());
                apprCrePg.setVehicleModel(eAppraiseVehicles.getVehicleModel());
                apprCrePg.setVehicleSeries(eAppraiseVehicles.getVehicleSeries());
                apprCrePg.setAppraisedValue(eAppraiseVehicles.getAppraisedValue());
                apprCrePg.setEnginePerfor(eAppraiseVehicles.getEnginePerfor());


                apprCrePg.setVehicleMileage(apprTstDriSts.getVehicleMileage());
                apprCrePg.setEngineType(apprTstDriSts.getEngineType());

                apprCrePg.setTransmissionType(apprTstDriSts.getTransmissionType());
                apprCrePg.setTransmiSts(apprTstDriSts.getTitleSts());
                apprCrePg.setVehicleExtColor(apprTstDriSts.getVehicleExtColor());
                apprCrePg.setVehicleInterior(apprTstDriSts.getVehicleInterior());
                apprCrePg.setDoorLocks(apprTstDriSts.getDoorLocks());
                apprCrePg.setRoofType(apprTstDriSts.getRoofType());
                apprCrePg.setLeftfrWinSts(apprTstDriSts.getLeftfrWinSts());
                apprCrePg.setFrRightWinSts(apprTstDriSts.getFrRightWinSts());
                apprCrePg.setRearLeftWinSts(apprTstDriSts.getRearLeftWinSts());
                apprCrePg.setRearRightWinSts(apprTstDriSts.getRearRightWinSts());
                apprCrePg.setQuickAppraisal(apprTstDriSts.getQuickAppraisal());
                apprCrePg.setVehiclePic1(apprTstDriSts.getVehiclePic1());
                apprCrePg.setVehiclePic2(apprTstDriSts.getVehiclePic2());
                apprCrePg.setVehiclePic3(apprTstDriSts.getVehiclePic3());
                apprCrePg.setVehiclePic4(apprTstDriSts.getVehiclePic4());
                apprCrePg.setVehiclePic5(apprTstDriSts.getVehiclePic5());
                apprCrePg.setVehiclePic6(apprTstDriSts.getVehiclePic6());
                apprCrePg.setVehiclePic7(apprTstDriSts.getVehiclePic7());
                apprCrePg.setVehiclePic8(apprTstDriSts.getVehiclePic8());
                apprCrePg.setVehiclePic9(apprTstDriSts.getVehiclePic9());
                apprCrePg.setVehicleVideo1(apprTstDriSts.getVehicleVideo1());

                apprCrePg.setExternalDmgSts(apprTstDriSts.getExternalDmgSts());
                apprCrePg.setFrDrSideDmgTxtBox(apprTstDriSts.getFrDrSideDmgTxtBox());
                apprCrePg.setFrDrSideDmgPic(apprTstDriSts.getFrDrSideDmgPic());


                apprCrePg.setRearPassenSideDmgSts(apprTstDriSts.getRearPassenSideDmgSts());
                apprCrePg.setRearDrSideDmgTxtBox(apprTstDriSts.getRearDrSideDmgTxtBox());

                apprCrePg.setRearDrSideDmgPic(apprTstDriSts.getRearDrSideDmgPic());

                apprCrePg.setRearPassenSideDmgSts(apprTstDriSts.getRearPassenSideDmgSts());
                apprCrePg.setRearPassenSideDmgTxtBox(apprTstDriSts.getRearPassenSideDmgTxtBox());
                apprCrePg.setRearPassenSideDmgPic(apprTstDriSts.getRearPassenSideDmgPic());


                apprCrePg.setFrDrSideDmgSts(apprTstDriSts.getFrDrSideDmgSts());

                apprCrePg.setFrPassenSideDmgTxtBox(apprTstDriSts.getFrPassenSideDmgTxtBox());
                apprCrePg.setFrPassenSideDmgPic(apprTstDriSts.getFrPassenSideDmgPic());
                apprCrePg.setPaintWork(apprTstDriSts.getPaintWork());

                apprCrePg.setFrDrSidePntWrkSts(apprTstDriSts.getFrDrSidePntWrkSts());
                apprCrePg.setFrDrSidePntWrkTxtBox(apprTstDriSts.getFrDrSidePntWrkTxtBox());
                apprCrePg.setFrDrSidePntWrkPic(apprTstDriSts.getFrDrSidePntWrkPic());

                apprCrePg.setRearDrSidePntWrk(apprTstDriSts.getRearDrSidePntWrk());
                apprCrePg.setRearDrSidePntWrkTxtBox(apprTstDriSts.getRearDrSidePntWrkTxtBox());
                apprCrePg.setRearDrSidePntWrkPic(apprTstDriSts.getRearDrSidePntWrkPic());

                apprCrePg.setRearPassenSidePntWrk(apprTstDriSts.getRearPassenSidePntWrk());
                apprCrePg.setRearPassenSidePntWrkTxtBox(apprTstDriSts.getRearPassenSidePntWrkTxtBox());
                apprCrePg.setRearPassenSidePntWrkPic(apprTstDriSts.getRearPassenSidePntWrkPic());

                apprCrePg.setFrPassenSidePntWrk(apprTstDriSts.getFrPassenSidePntWrk());
                apprCrePg.setFrPassenSidePntWrkTxtBox(apprTstDriSts.getFrPassenSidePntWrkTxtBox());
                apprCrePg.setFrPassenSidePntWrkPic(apprTstDriSts.getFrPassenSidePntWrkPic());

                apprCrePg.setFrWindshieldDmg(apprTstDriSts.getFrWindshieldDmg());
                apprCrePg.setRearGlassDmg(apprTstDriSts.getRearGlassDmg());
                apprCrePg.setSteeringFeelSts(apprTstDriSts.getSteeringFeelSts());

                apprCrePg.setKeyAssureYes(apprTstDriSts.getKeyAssureYes());
                apprCrePg.setSubscribToKeyAssure(apprTstDriSts.getSubscribToKeyAssure());
                apprCrePg.setKeyAssureFiles(apprTstDriSts.getKeyAssureFiles());
                apprCrePg.setBrakingSysSts(apprTstDriSts.getBrakingSysSts());
                apprCrePg.setBooksAndKeys(apprTstDriSts.getBooksAndKeys());
                apprCrePg.setTitleSts(apprTstDriSts.getTitleSts());
                apprCrePg.setProfOpinion(apprTstDriSts.getProfOpinion());
                apprCrePg.setVehicleDesc(apprTstDriSts.getVehicleDesc());
                apprCrePg.setAdjustedWholeFair(apprTstDriSts.getAdjustedWholeFair());
                apprCrePg.setAdjustedWholePoor(apprTstDriSts.getAdjustedWholePoor());
                apprCrePg.setAdjustedWholeGood(apprTstDriSts.getAdjustedWholeGood());
                apprCrePg.setAdjustedWholeVeryGood(apprTstDriSts.getAdjustedWholeVeryGood());
                apprCrePg.setAdjustedWholeExcelnt(apprTstDriSts.getAdjustedWholeExcelnt());
                apprCrePg.setAdjustedFinanPoor(apprTstDriSts.getAdjustedFinanPoor());
                apprCrePg.setAdjustedFinanFair(apprTstDriSts.getAdjustedFinanFair());
                apprCrePg.setAdjustedFinanExcelnt(apprTstDriSts.getAdjustedFinanExcelnt());
                apprCrePg.setAdjustedRetailPoor(apprTstDriSts.getAdjustedRetailPoor());
                apprCrePg.setAdjustedRetailFair(apprTstDriSts.getAdjustedRetailFair());
                apprCrePg.setAdjustedRetailGood(apprTstDriSts.getAdjustedRetailGood());
                apprCrePg.setAdjustedRetailVeryGood(apprTstDriSts.getAdjustedRetailVeryGood());
                apprCrePg.setAdjustedRetailExcelnt(apprTstDriSts.getAdjustedRetailExcelnt());
                apprCrePg.setDealerReserve(apprTstDriSts.getDealerReserve());
                apprCrePg.setComsumerAskPrice(apprTstDriSts.getComsumerAskPrice());
                apprCrePg.setDelrRetlAskPrice(apprTstDriSts.getDelrRetlAskPrice());
                apprCrePg.setPushForBuyFig(apprTstDriSts.getPushForBuyFig());


                //  apprCrePg.setESign(signDet.getESign());

                ArrayList<String> apprVehAcConList = showInEditSetAcCond(apprVehAcCon);
                apprCrePg.setAcCondition(apprVehAcConList);

                ArrayList<String> appVehSteStsList = showInEditSetSteroSts(apprVehSteSts);
                apprCrePg.setStereoSts(appVehSteStsList);

                ArrayList<String> appVehIntConList = showInEditSetInteriCond(apprVehIntCon);
                apprCrePg.setInteriorCondn(appVehIntConList);

                ArrayList<String> appvehOlConList = showInEditSetOilCond(apprVehOlCond);
                apprCrePg.setOilCondition(appvehOlConList);

                ArrayList<String> dashWrngLtList = showInEditSetWarnLightsts(appVehDriWarnLight);
                apprCrePg.setDashWarningLights(dashWrngLtList);


            } else throw new RuntimeException("Invalid Apraisal Id");

        }catch (RuntimeException ex){
            Response errorResponse= new Response(HttpStatus.INTERNAL_SERVER_ERROR.value(), ex.getMessage());
            return errorResponse;

        }

        return apprCrePg;

    }

@Override
    public Response updateAppraisal(ApprCreaPage page, Long apprId){

        EAppraiseVehicle vehicle = eAppraiseVehicleRepo.findById(apprId).orElse(null);
//        try {
            if (null!=vehicle) {

                EApprTestDrSts testDriveStatus = vehicle.getApprTestDrSts();
                EApprVehAcCondn eApprVehAcCondn = testDriveStatus.getApprVehAcCondn();
                EApprVehOilCondn eApprVehOilCondn = testDriveStatus.getApprVehOilCondn();
                EApprVehInteriCondn intrCondn = testDriveStatus.getApprVehInteriCondn();
                EApprVehStereoSts eApprVehStereoSts = testDriveStatus.getApprVehStereoSts();
                EVehDrWarnLightSts eVehDrWarnLightSts = testDriveStatus.getVehDrWarnLightSts();
                ESignDet eSignDet= vehicle.getSignDet();



                //update EAppraiseVehicle


                if(null!=vehicle.getEnginePerfor()) {

                    if(!page.getEnginePerfor().equals(vehicle.getEnginePerfor()))
                        vehicle.setEnginePerfor(page.getEnginePerfor());

                }else {
                    vehicle.setEnginePerfor(page.getEnginePerfor());

                }

                if(null!=vehicle.getTransmiSts()) {

                    if(!page.getTransmiSts().equals(vehicle.getTransmiSts()))
                        vehicle.setTransmiSts(page.getTransmiSts());

                }else {
                    vehicle.setTransmiSts(page.getTransmiSts());

                }

                if(0!=vehicle.getAppraisedValue()) {

                    if(!(page.getAppraisedValue()==vehicle.getAppraisedValue()))
                        vehicle.setAppraisedValue(page.getAppraisedValue());

                }else {
                    vehicle.setAppraisedValue(page.getAppraisedValue());

                }


                //update esign

//                if(null!=eSignDet.getSignDocument()) {
//
//                    if(!page.getESign().equals(eSignDet.getSignDocument()))
//                        eSignDet.setSignDocument(page.getESign());
//
//                }else {
//                    eSignDet.setSignDocument(page.getESign());
//
//                }




                //update EAppraisalTestDriveStatus

                EApprTestDrSts eApprTestDrSts = updateTestDrSts(testDriveStatus, page);



                //update EAppraisalVehicleAcCondition

                List<String> acCondition = page.getAcCondition();
                EApprVehAcCondn eApprVehAcCondn1 = updateAcCondn(eApprVehAcCondn, acCondition);


                //update EVehicleDrivingWarnLightStatus

                List<String> dashWarningLights = page.getDashWarningLights();
                EVehDrWarnLightSts eVehDrWarnLightSts1 = updateDrWarnLight(eVehDrWarnLightSts, dashWarningLights);


                //update stereoStatus

                List<String> stereoStatus = page.getStereoSts();
                EApprVehStereoSts eApprVehStereoSts1 = updateStereoSts(eApprVehStereoSts, stereoStatus);


                //update oilCondition

                List<String> oilCondition = page.getOilCondition();
                EApprVehOilCondn eApprVehOilCondn1 = updateOilCondn(eApprVehOilCondn, oilCondition);


                //update interiorCondition
                List<String> interiorCondition = page.getInteriorCondn();
                EApprVehInteriCondn interiCondn = updateInteriCondn(intrCondn, interiorCondition);


                eAppraiseVehicleRepo.save(vehicle);
               // signDetRepo.save(eSignDet);
                eApprTestDrStsRepo.save(eApprTestDrSts);
                acConditionRepo.save(eApprVehAcCondn1);
                warnLightStatusRepo.save(eVehDrWarnLightSts1);
                stereoStatusRepo.save(eApprVehStereoSts1);
                oilConditionRepo.save(eApprVehOilCondn1);
                interiorConditionRepo.save(interiCondn);

            }

            else throw new RuntimeException("Invalid Appraisal id Send..");
//        }
//        catch (RuntimeException exception){
//            Response response =new Response();
//            response.setMessage(exception.getMessage());
//            response.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
//            return response;
//        }
          Response response =new Response();
            response.setMessage("Updated Sucessfully");
            response.setCode(HttpStatus.OK.value());
            return response;
    }

    @Override
    public String videoUpload(MultipartFile file) {

        String extension = FilenameUtils.getExtension(file.getOriginalFilename());
        String filename = UUID.randomUUID().toString() + "." + extension;
        Path filePath = Paths.get(AppraisalConstants.VIDEO_FOLDER_PATH+ filename);
        try{ Files.write(filePath, file.getBytes());
        }
        catch (IOException exception){
            log.error(exception.getMessage());
        }


        return filename;
    }

    @Override
    public  VideoResponse videoDownload(String videoName) {
        VideoResponse responseDTO = new VideoResponse();
        try {

            String filePath = AppraisalConstants.VIDEO_FOLDER_PATH + videoName;

            byte[] videoBytes = Files.readAllBytes(new File(filePath).toPath());//Reading from folder


            responseDTO.setVideoBytes(videoBytes);
            return responseDTO;

        } catch (IOException ex) {

            responseDTO.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
            responseDTO.setMessage(ex.getMessage());
            return responseDTO;
        }


    }

    @Override
    public Response deleteAppraisalVehicle(Long apprRef) {
        EAppraiseVehicle appraisal = eAppraiseVehicleRepo.findById(apprRef).orElse(null);
         Response response=new Response();
         try {
             if (null!= appraisal && appraisal.getValid()) {

                 appraisal.setValid(false);
                 eAppraiseVehicleRepo.save(appraisal);

                 response.setMessage("Deleted Successfully");
                 response.setCode(HttpStatus.OK.value());

             } else
                 throw new RuntimeException("Did not find AppraisalVehicle of  - " + apprRef);
         }catch (RuntimeException exception){
             response.setMessage(exception.getMessage());
             response.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
             return response;
         }
        return response;
    }

    private EApprVehAcCondn AddApprSetACCond(List<String> acCond){

        EApprVehAcCondn eApprVehAcCondn = new EApprVehAcCondn();

        for (int i = 0; i < acCond.size(); i++) {

            if (acCond.get(i).equals("fanSpeedMalfun")) {
                eApprVehAcCondn.setFanSpeedMalfun(true);
            }
            else if (acCond.get(i).equals("coldAir")) {
                eApprVehAcCondn.setColdAir(true);
            }
            else if (acCond.get(i).equals("badDisplay")) {
                eApprVehAcCondn.setBadDisplay(true);
            }
            else if (acCond.get(i).equals("fadedDisOrBtn")) {
                eApprVehAcCondn.setFadedDisOrBtn(true);
            }
            else if (acCond.get(i).equals("climateCtrlMalfun")) {
                eApprVehAcCondn.setClimateCtrlMalfun(true);
            }
            else if (acCond.get(i).equals("hotOrWarmAir")) {
                eApprVehAcCondn.setHotOrWarmAir(true);
            }
            else if (acCond.get(i).equals("notOperational")) {
                eApprVehAcCondn.setNotOperational(true);
            }
        }

        return eApprVehAcCondn;

    }
    private EVehDrWarnLightSts AddApprSetVehWarnLightCond(List<String> warnLightSts){

        EVehDrWarnLightSts eWarnLightStatus = new EVehDrWarnLightSts();

        for (int i = 0; i < warnLightSts.size(); i++) {
            if (warnLightSts.get(i).equals("noFaults")) {
                eWarnLightStatus.setNoFaults(true);
            }
            else if (warnLightSts.get(i).equals("absLight")) {
                eWarnLightStatus.setAbsLight(true);
            }
            else if (warnLightSts.get(i).equals("airBagFault")) {
                eWarnLightStatus.setAirBagFault(true);
            }
            else if (warnLightSts.get(i).equals("batteryFault")) {
                eWarnLightStatus.setBatteryFault(true);
            }
            else if (warnLightSts.get(i).equals("brakeSystem")) {
                eWarnLightStatus.setBrakeSystem(true);
            }
            else if (warnLightSts.get(i).equals("brakePadWear")) {
                eWarnLightStatus.setBrakePadWear(true);
            }
            else if (warnLightSts.get(i).equals("chargingSystem")) {
                eWarnLightStatus.setChargingSystem(true);
            }
            else if (warnLightSts.get(i).equals("coolantLevel")) {
                eWarnLightStatus.setCoolantLevel(true);
            }
            else if (warnLightSts.get(i).equals("coolantTemp")) {
                eWarnLightStatus.setCoolantTemp(true);
            }
            else if (warnLightSts.get(i).equals("checkEngineLight")) {
                eWarnLightStatus.setCheckEngineLight(true);
            }
            else if (warnLightSts.get(i).equals("oilPressure")) {
                eWarnLightStatus.setOilPressure(true);
            }
            else if (warnLightSts.get(i).equals("serviceEngineSoon")) {
                eWarnLightStatus.setServiceEngineSoon(true);
            }
            else if (warnLightSts.get(i).equals("steeringFaults")) {
                eWarnLightStatus.setSteeringFaults(true);
            }
            else if (warnLightSts.get(i).equals("suspensionSystem")) {
                eWarnLightStatus.setSuspensionSystem(true);
            }
            else if (warnLightSts.get(i).equals("tractionControl")) {
                eWarnLightStatus.setTractionControl(true);
            }
            else if (warnLightSts.get(i).equals("transmiFault")) {
                eWarnLightStatus.setTransmiFault(true);
            }
            else if (warnLightSts.get(i).equals("dislExhFluidLight")) {
                eWarnLightStatus.setDislExhFluidLight(true);
            }
            else if (warnLightSts.get(i).equals("dislParticulateFilt")) {
                eWarnLightStatus.setDislParticulateFilt(true);
            }
        }
        return eWarnLightStatus;
    }

    private EApprVehStereoSts AddApprSetApprVehStereoSts(List<String> vehStereoSts){

        EApprVehStereoSts eStereoStatus = new EApprVehStereoSts();

        for (int i = 0; i < vehStereoSts.size(); i++) {
            if (vehStereoSts.get(i).equals("factoryEquptOperat")) {
                eStereoStatus.setFactoryEquptOperat(true);
            }
            else if (vehStereoSts.get(i).equals("factoryEquptNotOperat")) {
                eStereoStatus.setFactoryEquptNotOperat(true);
            }
            else if (vehStereoSts.get(i).equals("knobsMissing")) {
                eStereoStatus.setKnobsMissing(true);
            }
            else if (vehStereoSts.get(i).equals("aftMktNavigaNiceSys")) {
                eStereoStatus.setAftMktNavigaNiceSys(true);
            }
            else if (vehStereoSts.get(i).equals("afterMarket")) {
                eStereoStatus.setAfterMarket(true);
            }
            else if (vehStereoSts.get(i).equals("aftMktRearEntertainSys")) {
                eStereoStatus.setAftMktRearEntertainSys(true);
            }
            else if (vehStereoSts.get(i).equals("factoryRearEntertainSys")) {
                eStereoStatus.setFactoryRearEntertainSys(true);
            }
            else if (vehStereoSts.get(i).equals("brokenScreen")) {
                eStereoStatus.setBrokenScreen(true);
            }
            else if (vehStereoSts.get(i).equals("fadedDisBtn")) {
                eStereoStatus.setFadedDisBtn(true);
            }
            else if (vehStereoSts.get(i).equals("profInstall")) {
                eStereoStatus.setProfInstall(true);
            }
            else if (vehStereoSts.get(i).equals("notOperational")) {
                eStereoStatus.setNotOperational(true);
            }
            else if (vehStereoSts.get(i).equals("operational")) {
                eStereoStatus.setOperational(true);
            }
        }

        return eStereoStatus;
    }

    private EApprVehInteriCondn AddApprSetVehInteriorCond(List<String> vehIntCond){

        EApprVehInteriCondn eInteriorCondition = new EApprVehInteriCondn();

        for (int i = 0; i < vehIntCond.size(); i++) {
            if (vehIntCond.get(i).equals("cleanFL")) {
                eInteriorCondition.setCleanFL(true);
            }
            else if (vehIntCond.get(i).equals("goodMnrRepaisNeed")) {
                eInteriorCondition.setGoodMnrRepaisNeed(true);
            }
            else if (vehIntCond.get(i).equals("smokersCar")) {
                eInteriorCondition.setSmokersCar(true);
            }
            else if (vehIntCond.get(i).equals("oddSmelling")) {
                eInteriorCondition.setOddSmelling(true);
            }
            else if (vehIntCond.get(i).equals("veryDirty")) {
                eInteriorCondition.setVeryDirty(true);
            }
            else if (vehIntCond.get(i).equals("driversSeatWear")) {
                eInteriorCondition.setDriversSeatWear(true);
            }
            else if (vehIntCond.get(i).equals("headlineNeedRplc")) {
                eInteriorCondition.setHeadlineNeedRplc(true);
            }
            else if (vehIntCond.get(i).equals("driverSeatRipped")) {
                eInteriorCondition.setDriverSeatRipped(true);
            }
            else if (vehIntCond.get(i).equals("dashCrackedMinor")) {
                eInteriorCondition.setDashCrackedMinor(true);
            }
            else if (vehIntCond.get(i).equals("dashCrackBrknMaj")) {
                eInteriorCondition.setDashCrackBrknMaj(true);
            }
            else if (vehIntCond.get(i).equals("passenSeatRipped")) {
                eInteriorCondition.setPassenSeatRipped(true);
            }
            else if (vehIntCond.get(i).equals("strongPetSmell")) {
                eInteriorCondition.setStrongPetSmell(true);
            }
            else if (vehIntCond.get(i).equals("carpetBadlyWorn")) {
                eInteriorCondition.setCarpetBadlyWorn(true);
            }
            else if (vehIntCond.get(i).equals("interTrimBrknnMiss")) {
                eInteriorCondition.setInterTrimBrknnMiss(true);
            }
            else if (vehIntCond.get(i).equals("poorNeedsRepair")) {
                eInteriorCondition.setPoorNeedsRepair(true);
            }
        }

        return eInteriorCondition;
    }

    private EApprVehOilCondn AddApprSetVehOilCond(List<String> vehOilCond){

        EApprVehOilCondn eOilCondition = new EApprVehOilCondn();

        for (int i = 0; i < vehOilCond.size(); i++) {
            if (vehOilCond.get(i).equals("cleanOil")) {
                eOilCondition.setCleanOil(true);
            }
            else if (vehOilCond.get(i).equals("dirtyOil")) {
                eOilCondition.setDirtyOil(true);
            }
            else if (vehOilCond.get(i).equals("waterInOil")) {
                eOilCondition.setWaterInOil(true);
            }
            else if (vehOilCond.get(i).equals("correctLevel")) {
                eOilCondition.setCorrectLevel(true);
            }
            else if (vehOilCond.get(i).equals("oneQuartLow")) {
                eOilCondition.setOneQuartLow(true);
            }
            else if (vehOilCond.get(i).equals("greaterThanAQuartLow")) {
                eOilCondition.setGreaterThanAQuartLow(true);
            }
            else if (vehOilCond.get(i).equals("electronicGauge")) {
                eOilCondition.setElectronicGauge(true);
            }
        }
        return eOilCondition;
    }



    private ArrayList<String> showInEditSetAcCond(EApprVehAcCondn apprVehAcCon){

        ArrayList<String> apprVehAcConList = new ArrayList<>();
        if (apprVehAcCon.isBadDisplay())
            apprVehAcConList.add("badDisplay");

        if (apprVehAcCon.isColdAir())
            apprVehAcConList.add("coldAir");

        if (apprVehAcCon.isFadedDisOrBtn())
            apprVehAcConList.add("fadedDisOrBtn");

        if (apprVehAcCon.isFanSpeedMalfun())
            apprVehAcConList.add("fanSpeedMalfun");

        if (apprVehAcCon.isClimateCtrlMalfun())
            apprVehAcConList.add("climateCtrlMalfun");

        if (apprVehAcCon.isHotOrWarmAir())
            apprVehAcConList.add("hotOrWarmAir");

        if (apprVehAcCon.isNotOperational())
            apprVehAcConList.add("notOperational");


        return apprVehAcConList;


    }
    private ArrayList<String> showInEditSetOilCond(EApprVehOilCondn apprVehOlCond) {
        ArrayList<String> appvehOlConList = new ArrayList<>();
        if (apprVehOlCond.isCleanOil())
            appvehOlConList.add("cleanOil");
        if (apprVehOlCond.isDirtyOil())
            appvehOlConList.add("dirtyOil");
        if (apprVehOlCond.isWaterInOil())
            appvehOlConList.add("waterInOil");
        if (apprVehOlCond.isCorrectLevel())
            appvehOlConList.add("correctLevel");
        if (apprVehOlCond.isOneQuartLow())
            appvehOlConList.add("oneQuartLow");
        if (apprVehOlCond.isGreaterThanAQuartLow())
            appvehOlConList.add("greaterThanAQuartLow");
        if (apprVehOlCond.isElectronicGauge())
            appvehOlConList.add("electronicGauge");

        return appvehOlConList;
    }

    /**
     *this method checking the
     * @param apprVehSteSts
     * @return
     */

    private ArrayList<String> showInEditSetSteroSts(EApprVehStereoSts apprVehSteSts) {

        ArrayList<String> appVehSteStsList = new ArrayList<>();

        if (apprVehSteSts.isFactoryEquptOperat())

            appVehSteStsList.add("factoryEquptOperat");
        if (apprVehSteSts.isFactoryEquptNotOperat())

            appVehSteStsList.add("factoryEquptNotOperat");
        if (apprVehSteSts.isKnobsMissing())

            appVehSteStsList.add("knobsMissing");
        if (apprVehSteSts.isAftMktNavigaNiceSys())

            appVehSteStsList.add("aftMktNavigaNiceSys");
        if (apprVehSteSts.isAfterMarket())

            appVehSteStsList.add("afterMarket");

        if (apprVehSteSts.isAftMktRearEntertainSys())

            appVehSteStsList.add("aftMktRearEntertainSys ");

        if (apprVehSteSts.isProfInstall())
            appVehSteStsList.add("profInstall");

        if (apprVehSteSts.isFadedDisBtn())
            appVehSteStsList.add("fadedDisBtn");
        if (apprVehSteSts.isNotOperational())

            appVehSteStsList.add("notOperational");

        if (apprVehSteSts.isOperational())

            appVehSteStsList.add("operational");

        return appVehSteStsList;
    }

    /**
     * this method is checking interior condition
     * @param apprVehIntCon getting from DB
     * @return list of interior conditon to UI
     */

    private ArrayList<String> showInEditSetInteriCond(EApprVehInteriCondn apprVehIntCon) {

        ArrayList<String> appVehIntConList = new ArrayList<>();

        if (apprVehIntCon.isCleanFL())
            appVehIntConList.add("cleanFL");

        if (apprVehIntCon.isGoodMnrRepaisNeed())

            appVehIntConList.add("goodMnrRepaisNeed");
        if (apprVehIntCon.isSmokersCar())
            appVehIntConList.add("smokersCar");
        if (apprVehIntCon.isStrongPetSmell())
            appVehIntConList.add("strongPetSmell");

        if (apprVehIntCon.isDriversSeatWear())
            appVehIntConList.add("driversSeatWear");

        if (apprVehIntCon.isHeadlineNeedRplc())
            appVehIntConList.add("headlineNeedRplc");

        if (apprVehIntCon.isDriverSeatRipped())
            appVehIntConList.add("driverSeatRipped");

        if (apprVehIntCon.isDashCrackBrknMaj())
            appVehIntConList.add("dashCrackBrknMaj");

        if (apprVehIntCon.isPassenSeatRipped())
            appVehIntConList.add("passengerSeatRipped ");


        if (apprVehIntCon.isCarpetBadlyWorn())
            appVehIntConList.add("carpetBadlyWorn");

        if (apprVehIntCon.isInterTrimBrknnMiss())
            appVehIntConList.add("interTrimBrknnMiss");

        if (apprVehIntCon.isPoorNeedsRepair())
            appVehIntConList.add("poorNeedsRepair");

        return appVehIntConList;
    }

    /**
     * this method setting the values present in database to dto
     * @param appVehDriWarnLight coming from db
     * @return return list to ui
     */
    private ArrayList<String> showInEditSetWarnLightsts(EVehDrWarnLightSts appVehDriWarnLight) {

        ArrayList<String> dashWrngLtList = new ArrayList<>();
        if (appVehDriWarnLight.isNoFaults())
            dashWrngLtList.add("noFaults");
        if (appVehDriWarnLight.isAbsLight())
            dashWrngLtList.add("absLight");
        if (appVehDriWarnLight.isBatteryFault())
            dashWrngLtList.add("batteryFault");
        if (appVehDriWarnLight.isBrakeSystem())
            dashWrngLtList.add("brakeSystem");
        if (appVehDriWarnLight.isBrakePadWear())
            dashWrngLtList.add("brakePadWear");
        if (appVehDriWarnLight.isChargingSystem())
            dashWrngLtList.add("chargingSystem");
        if (appVehDriWarnLight.isCoolantLevel())
            dashWrngLtList.add("coolantLevel");
        if (appVehDriWarnLight.isOilPressure())
            dashWrngLtList.add("oilPressure");
        if (appVehDriWarnLight.isServiceEngineSoon())
            dashWrngLtList.add("serviceEngineSoon");
        if (appVehDriWarnLight.isSteeringFaults())
            dashWrngLtList.add("steeringFaults");
        if (appVehDriWarnLight.isSuspensionSystem())
            dashWrngLtList.add("suspensionSystem");
        if (appVehDriWarnLight.isTractionControl())
            dashWrngLtList.add("tractionControl");
        if (appVehDriWarnLight.isTransmiFault())
            dashWrngLtList.add("transmiFault");
        if (appVehDriWarnLight.isDislExhFluidLight())
            dashWrngLtList.add("dislExhFluidLight");
        if (appVehDriWarnLight.isDislParticulateFilt())
            dashWrngLtList.add("dislParticulateFilt");

        return dashWrngLtList;
    }

    /**
     * method to update the old picture with new picture
     * @param newPic new pic coming from UI
     * @param oldPic is present in databse will get deleted
     * @return
     */

    private Boolean updatePics(String newPic, String oldPic){

        if(!newPic.equals(oldPic) && null!=newPic) {
            Path filePath = Paths.get(AppraisalConstants.IMAGE_FOLDER_PATH + oldPic);
            try {
                Files.delete(filePath);
            } catch (IOException ex) {
                log.error(ex.getMessage());
            }
            return true;
        }
        else
        return false;
    }

    /**
     * this method cheching for null and updating the existing fields
     * @param testDriveStatus coming from database
     * @param page coming from ui
     * @return
     */
    private EApprTestDrSts updateTestDrSts(EApprTestDrSts testDriveStatus,ApprCreaPage page){


        if(null!=testDriveStatus.getEngineType()) {

            if(!page.getEngineType().equals(testDriveStatus.getEngineType()))
                testDriveStatus.setEngineType(page.getEngineType());

        }
        else {
            testDriveStatus.setEngineType(page.getEngineType());

        }

        if(null!=testDriveStatus.getTransmissionType()) {

            if(!page.getTransmissionType().equals(testDriveStatus.getTransmissionType()))
                testDriveStatus.setTransmissionType(page.getTransmissionType());

        }
        else {
            testDriveStatus.setTransmissionType(page.getTransmissionType());

        }

        if(null!=testDriveStatus.getVehicleExtColor()) {

            if (!page.getVehicleExtColor().equals(testDriveStatus.getVehicleExtColor()))
                testDriveStatus.setVehicleExtColor(page.getVehicleExtColor());
        }else {
            testDriveStatus.setVehicleExtColor(page.getVehicleExtColor());

        }

        if(null!=testDriveStatus.getVehicleInterior()) {

            if (!page.getVehicleInterior().equals(testDriveStatus.getVehicleInterior()))
                testDriveStatus.setVehicleInterior(page.getVehicleInterior());
        }else {
            testDriveStatus.setVehicleInterior(page.getVehicleInterior());

        }

        if(null!=testDriveStatus.getDoorLocks()) {

            if (!page.getDoorLocks().equals(testDriveStatus.getDoorLocks()))
                testDriveStatus.setDoorLocks(page.getDoorLocks());
        }else {
            testDriveStatus.setDoorLocks(page.getDoorLocks());

        }

        if(null!=testDriveStatus.getRoofType()) {

            if (!page.getRoofType().equals(testDriveStatus.getRoofType()))
                testDriveStatus.setRoofType(page.getRoofType());
        }else {
            testDriveStatus.setRoofType(page.getDoorLocks());

        }

        if(null!=testDriveStatus.getLeftfrWinSts()) {

            if (!page.getLeftfrWinSts().equals(testDriveStatus.getLeftfrWinSts()))
                testDriveStatus.setLeftfrWinSts(page.getLeftfrWinSts());
        }else {
            testDriveStatus.setLeftfrWinSts(page.getLeftfrWinSts());

        }

        if(null!=testDriveStatus.getFrRightWinSts()) {

            if (!page.getFrRightWinSts().equals(testDriveStatus.getFrRightWinSts()))
                testDriveStatus.setFrRightWinSts(page.getFrRightWinSts());
        }else {
            testDriveStatus.setFrRightWinSts(page.getFrRightWinSts());

        }

        if(null!=testDriveStatus.getRearLeftWinSts()) {

            if (!page.getRearLeftWinSts().equals(testDriveStatus.getRearLeftWinSts()))
                testDriveStatus.setRearLeftWinSts(page.getRearLeftWinSts());
        }else {
            testDriveStatus.setRearLeftWinSts(page.getRearLeftWinSts());

        }

        if(null!=testDriveStatus.getRearRightWinSts()) {

            if (!page.getRearRightWinSts().equals(testDriveStatus.getRearRightWinSts()))
                testDriveStatus.setRearRightWinSts(page.getRearRightWinSts());
        }else {
            testDriveStatus.setRearRightWinSts(page.getRearRightWinSts());

        }

        if(null!=testDriveStatus.getQuickAppraisal()) {

            if (!page.getQuickAppraisal().equals(testDriveStatus.getQuickAppraisal()))
                testDriveStatus.setQuickAppraisal(page.getQuickAppraisal());
        }else {
            testDriveStatus.setQuickAppraisal(page.getQuickAppraisal());

        }

        if(null!=testDriveStatus.getExternalDmgSts()) {

            if (!page.getExternalDmgSts().equals(testDriveStatus.getExternalDmgSts()))
                testDriveStatus.setExternalDmgSts(page.getExternalDmgSts());
        }else {
            testDriveStatus.setExternalDmgSts(page.getExternalDmgSts());

        }

        if(null!=testDriveStatus.getFrDrSideDmgSts()) {

            if (!page.getFrDrSideDmgSts().equals(testDriveStatus.getFrDrSideDmgSts()))
                testDriveStatus.setFrDrSideDmgSts(page.getFrDrSideDmgSts());
        }else {
            testDriveStatus.setFrDrSideDmgSts(page.getFrDrSideDmgSts());

        }

        if(null!=testDriveStatus.getFrDrSideDmgTxtBox()) {

            if (!page.getFrDrSideDmgSts().equals(testDriveStatus.getFrDrSideDmgTxtBox()))
                testDriveStatus.setFrDrSideDmgTxtBox(page.getFrDrSideDmgTxtBox());
        }else {
            testDriveStatus.setFrDrSideDmgTxtBox(page.getFrDrSideDmgTxtBox());

        }

        if(null!=testDriveStatus.getFrDrSideDmgPic()) {

            if (!page.getFrDrSideDmgPic().equals(testDriveStatus.getFrDrSideDmgPic()))
                testDriveStatus.setFrDrSideDmgPic(page.getFrDrSideDmgPic());
        }else {
            testDriveStatus.setFrDrSideDmgPic(page.getFrDrSideDmgPic());

        }

        if(null!=testDriveStatus.getRearDrSideDmgSts()) {

            if (!page.getRearDrSideDmgSts().equals(testDriveStatus.getRearDrSideDmgSts()))
                testDriveStatus.setRearDrSideDmgSts(page.getRearDrSideDmgSts());
        }else {
            testDriveStatus.setRearDrSideDmgSts(page.getRearDrSideDmgSts());

        }

        if(null!=testDriveStatus.getRearDrSideDmgTxtBox()) {

            if (!page.getRearDrSideDmgTxtBox().equals(testDriveStatus.getRearDrSideDmgTxtBox()))
                testDriveStatus.setRearDrSideDmgTxtBox(page.getRearDrSideDmgTxtBox());
        }else {
            testDriveStatus.setRearDrSideDmgTxtBox(page.getRearDrSideDmgTxtBox());

        }

        if(null!=testDriveStatus.getRearDrSideDmgPic()) {

            if (!page.getRearDrSideDmgPic().equals(testDriveStatus.getRearDrSideDmgPic()))
                testDriveStatus.setRearDrSideDmgPic(page.getRearDrSideDmgPic());
        }else {
            testDriveStatus.setRearDrSideDmgPic(page.getRearDrSideDmgPic());

        }

        if(null!=testDriveStatus.getRearPassenSideDmgSts()) {

            if (!page.getRearPassenSideDmgSts().equals(testDriveStatus.getRearPassenSideDmgSts()))
                testDriveStatus.setRearPassenSideDmgSts(page.getRearPassenSideDmgSts());
        }else {
            testDriveStatus.setRearPassenSideDmgSts(page.getRearPassenSideDmgSts());

        }

        if(null!=testDriveStatus.getRearPassenSideDmgTxtBox()) {

            if (!page.getRearPassenSideDmgTxtBox().equals(testDriveStatus.getRearPassenSideDmgTxtBox()))
                testDriveStatus.setRearPassenSideDmgTxtBox(page.getRearPassenSideDmgTxtBox());
        }else {
            testDriveStatus.setRearPassenSideDmgTxtBox(page.getRearPassenSideDmgTxtBox());

        }

        if(null!=testDriveStatus.getRearPassenSideDmgPic()) {

            if (!page.getRearPassenSideDmgPic().equals(testDriveStatus.getRearPassenSideDmgPic()))
                testDriveStatus.setRearPassenSideDmgPic(page.getRearPassenSideDmgPic());
        }else {
            testDriveStatus.setRearPassenSideDmgPic(page.getRearPassenSideDmgPic());

        }

        if(null!=testDriveStatus.getFrPassenSideDmgSts()) {

            if (!page.getFrPassenSideDmgSts().equals(testDriveStatus.getFrPassenSideDmgSts()))
                testDriveStatus.setFrPassenSideDmgSts(page.getFrPassenSideDmgSts());
        }else {
            testDriveStatus.setFrPassenSideDmgSts(page.getFrPassenSideDmgSts());

        }

        if(null!=testDriveStatus.getFrPassenSideDmgTxtBox()) {

            if (!page.getFrPassenSideDmgTxtBox().equals(testDriveStatus.getFrPassenSideDmgTxtBox()))
                testDriveStatus.setFrPassenSideDmgTxtBox(page.getFrPassenSideDmgTxtBox());
        }else {
            testDriveStatus.setFrPassenSideDmgTxtBox(page.getFrPassenSideDmgTxtBox());

        }

        if(null!=testDriveStatus.getFrPassenSideDmgPic()) {

            if (!page.getFrPassenSideDmgPic().equals(testDriveStatus.getFrPassenSideDmgPic()))
                testDriveStatus.setFrPassenSideDmgPic(page.getFrPassenSideDmgPic());
        }else {
            testDriveStatus.setFrPassenSideDmgPic(page.getFrPassenSideDmgPic());

        }

        if(null!=testDriveStatus.getPaintWork()) {

            if (!page.getPaintWork().equals(testDriveStatus.getPaintWork()))
                testDriveStatus.setPaintWork(page.getPaintWork());
        }else {
            testDriveStatus.setPaintWork(page.getPaintWork());

        }

        if(null!=testDriveStatus.getFrDrSidePntWrkSts()) {

            if (!page.getFrDrSidePntWrkSts().equals(testDriveStatus.getFrDrSidePntWrkSts()))
                testDriveStatus.setFrDrSidePntWrkSts(page.getFrDrSidePntWrkSts());
        }else {
            testDriveStatus.setFrDrSidePntWrkSts(page.getFrDrSidePntWrkSts());

        }

        if(null!=testDriveStatus.getFrDrSidePntWrkTxtBox()) {

            if (!page.getFrDrSidePntWrkTxtBox().equals(testDriveStatus.getFrDrSidePntWrkTxtBox()))
                testDriveStatus.setFrDrSidePntWrkTxtBox(page.getFrDrSidePntWrkTxtBox());
        }else {
            testDriveStatus.setFrDrSidePntWrkTxtBox(page.getFrDrSidePntWrkTxtBox());

        }

        if(null!=testDriveStatus.getFrDrSidePntWrkPic()) {

            if (!page.getFrDrSidePntWrkPic().equals(testDriveStatus.getFrDrSidePntWrkPic()))
                testDriveStatus.setFrDrSidePntWrkPic(page.getFrDrSidePntWrkPic());
        }else {
            testDriveStatus.setFrDrSidePntWrkPic(page.getFrDrSidePntWrkPic());

        }

        if(null!=testDriveStatus.getRearDrSidePntWrk()) {

            if (!page.getRearDrSidePntWrk().equals(testDriveStatus.getRearDrSidePntWrk()))
                testDriveStatus.setRearDrSidePntWrk(page.getRearDrSidePntWrk());
        }else {
            testDriveStatus.setRearDrSidePntWrk(page.getRearDrSidePntWrk());

        }

        if(null!=testDriveStatus.getRearDrSidePntWrkTxtBox()) {

            if (!page.getRearDrSidePntWrkTxtBox().equals(testDriveStatus.getRearDrSidePntWrkTxtBox()))
                testDriveStatus.setRearDrSidePntWrkTxtBox(page.getRearDrSidePntWrkTxtBox());
        }else {
            testDriveStatus.setRearDrSidePntWrkTxtBox(page.getRearDrSidePntWrkTxtBox());

        }

        if(null!=testDriveStatus.getRearDrSidePntWrkPic()) {

            if (!page.getRearDrSidePntWrkPic().equals(testDriveStatus.getRearDrSidePntWrkPic()))
                testDriveStatus.setRearDrSidePntWrkPic(page.getRearDrSidePntWrkPic());
        }else {
            testDriveStatus.setRearDrSidePntWrkPic(page.getRearDrSidePntWrkPic());

        }

        if(null!=testDriveStatus.getRearDrSidePntWrk()) {

            if (!page.getRearDrSidePntWrk().equals(testDriveStatus.getRearDrSidePntWrk()))
                testDriveStatus.setRearDrSidePntWrk(page.getRearDrSidePntWrk());
        }else {
            testDriveStatus.setRearDrSidePntWrk(page.getRearDrSidePntWrk());

        }

        if(null!=testDriveStatus.getRearDrSidePntWrkTxtBox()) {

            if (!page.getRearDrSidePntWrkTxtBox().equals(testDriveStatus.getRearDrSidePntWrkTxtBox()))
                testDriveStatus.setRearDrSidePntWrkTxtBox(page.getRearDrSidePntWrkTxtBox());
        }else {
            testDriveStatus.setRearDrSidePntWrkTxtBox(page.getRearDrSidePntWrkTxtBox());

        }

        if(null!=testDriveStatus.getRearDrSidePntWrkPic()) {

            if (!page.getRearDrSidePntWrkPic().equals(testDriveStatus.getRearDrSidePntWrkPic()))
                testDriveStatus.setRearDrSidePntWrkPic(page.getRearDrSidePntWrkPic());
        }else {
            testDriveStatus.setRearDrSidePntWrkPic(page.getRearDrSidePntWrkPic());

        }

        if(null!=testDriveStatus.getFrPassenSidePntWrk()) {

            if (!page.getFrPassenSidePntWrk().equals(testDriveStatus.getFrPassenSidePntWrk()))
                testDriveStatus.setFrPassenSidePntWrk(page.getFrPassenSidePntWrk());
        }else {
            testDriveStatus.setFrPassenSidePntWrk(page.getFrPassenSidePntWrk());

        }

        if(null!=testDriveStatus.getFrPassenSidePntWrkTxtBox()) {

            if (!page.getFrPassenSidePntWrkTxtBox().equals(testDriveStatus.getFrPassenSidePntWrkTxtBox()))
                testDriveStatus.setFrPassenSidePntWrkTxtBox(page.getFrPassenSidePntWrkTxtBox());
        }else {
            testDriveStatus.setFrPassenSidePntWrkTxtBox(page.getFrPassenSidePntWrkTxtBox());

        }

        if(null!=testDriveStatus.getFrPassenSidePntWrkPic()) {

            if (!page.getFrPassenSidePntWrkPic().equals(testDriveStatus.getFrPassenSidePntWrkPic()))
                testDriveStatus.setFrPassenSidePntWrkPic(page.getFrPassenSidePntWrkPic());
        }else {
            testDriveStatus.setFrPassenSidePntWrkPic(page.getFrPassenSidePntWrkPic());

        }

        if(null!=testDriveStatus.getFrWindshieldDmg()) {

            if (!page.getFrWindshieldDmg().equals(testDriveStatus.getFrWindshieldDmg()))
                testDriveStatus.setFrWindshieldDmg(page.getFrWindshieldDmg());
        }else {
            testDriveStatus.setFrWindshieldDmg(page.getFrWindshieldDmg());

        }

        if(null!=testDriveStatus.getRearGlassDmg()) {

            if (!page.getRearGlassDmg().equals(testDriveStatus.getRearGlassDmg()))
                testDriveStatus.setRearGlassDmg(page.getRearGlassDmg());
        }else {
            testDriveStatus.setRearGlassDmg(page.getRearGlassDmg());

        }


        if(null!=testDriveStatus.getKeyAssureYes()) {

            if (!page.getKeyAssureYes().equals(testDriveStatus.getKeyAssureYes()))
                testDriveStatus.setKeyAssureYes(page.getKeyAssureYes());
        }else {
            testDriveStatus.setKeyAssureYes(page.getKeyAssureYes());

        }

        if(null!=testDriveStatus.getSubscribToKeyAssure()) {

            if (!page.getSubscribToKeyAssure().equals(testDriveStatus.getSubscribToKeyAssure()))
                testDriveStatus.setSubscribToKeyAssure(page.getSubscribToKeyAssure());
        }else {
            testDriveStatus.setSubscribToKeyAssure(page.getSubscribToKeyAssure());

        }

        if(null!=testDriveStatus.getKeyAssureFiles()) {

            if (!page.getKeyAssureFiles().equals(testDriveStatus.getKeyAssureFiles()))
                testDriveStatus.setKeyAssureFiles(page.getKeyAssureFiles());
        }else {
            testDriveStatus.setKeyAssureFiles(page.getKeyAssureFiles());

        }

        if(null!=testDriveStatus.getBrakingSysSts()) {

            if (!page.getBrakingSysSts().equals(testDriveStatus.getBrakingSysSts()))
                testDriveStatus.setBrakingSysSts(page.getBrakingSysSts());
        }else {
            testDriveStatus.setBrakingSysSts(page.getBrakingSysSts());

        }

        if(null!=testDriveStatus.getSteeringFeelSts()) {

            if (!page.getSteeringFeelSts().equals(testDriveStatus.getSteeringFeelSts()))
                testDriveStatus.setSteeringFeelSts(page.getSteeringFeelSts());
        }else {
            testDriveStatus.setSteeringFeelSts(page.getSteeringFeelSts());

        }

        if(null!=testDriveStatus.getBooksAndKeys()) {

            if (!page.getBooksAndKeys().equals(testDriveStatus.getBooksAndKeys()))
                testDriveStatus.setBooksAndKeys(page.getBooksAndKeys());
        }else {
            testDriveStatus.setBooksAndKeys(page.getBooksAndKeys());

        }

        if(null!=testDriveStatus.getTitleSts()) {

            if (!page.getTitleSts().equals(testDriveStatus.getTitleSts()))
                testDriveStatus.setTitleSts(page.getTitleSts());
        }else {
            testDriveStatus.setTitleSts(page.getTitleSts());

        }

        if(null!=testDriveStatus.getProfOpinion()) {

            if (!page.getProfOpinion().equals(testDriveStatus.getProfOpinion()))
                testDriveStatus.setProfOpinion(page.getProfOpinion());
        }else {
            testDriveStatus.setProfOpinion(page.getProfOpinion());

        }

        if(null!=testDriveStatus.getAdjustedWholePoor()) {

            if (!page.getAdjustedWholePoor().equals(testDriveStatus.getAdjustedWholePoor()))
                testDriveStatus.setAdjustedWholePoor(page.getAdjustedWholePoor());
        }else {
            testDriveStatus.setAdjustedWholePoor(page.getAdjustedWholePoor());

        }

        if(null!=testDriveStatus.getAdjustedWholeFair()) {

            if (!page.getAdjustedWholeFair().equals(testDriveStatus.getAdjustedWholeFair()))
                testDriveStatus.setAdjustedWholeFair(page.getAdjustedWholeFair());
        }else {
            testDriveStatus.setAdjustedWholeFair(page.getAdjustedWholeFair());

        }

        if(null!=testDriveStatus.getAdjustedWholeGood()) {

            if (!page.getAdjustedWholeGood().equals(testDriveStatus.getAdjustedWholeGood()))
                testDriveStatus.setAdjustedWholeGood(page.getAdjustedWholeGood());
        }else {
            testDriveStatus.setAdjustedWholeGood(page.getAdjustedWholeGood());

        }

        if(null!=testDriveStatus.getAdjustedWholeVeryGood()) {

            if (!page.getAdjustedWholeVeryGood().equals(testDriveStatus.getAdjustedWholeVeryGood()))
                testDriveStatus.setAdjustedWholeVeryGood(page.getAdjustedWholeVeryGood());
        }else {
            testDriveStatus.setAdjustedWholeVeryGood(page.getAdjustedWholeVeryGood());

        }

        if(null!=testDriveStatus.getAdjustedWholeExcelnt()) {

            if (!page.getAdjustedWholeExcelnt().equals(testDriveStatus.getAdjustedWholeExcelnt()))
                testDriveStatus.setAdjustedWholeExcelnt(page.getAdjustedWholeExcelnt());
        }else {
            testDriveStatus.setAdjustedWholeExcelnt(page.getAdjustedWholeExcelnt());

        }

        if(null!=testDriveStatus.getAdjustedFinanPoor()) {

            if (!page.getAdjustedFinanPoor().equals(testDriveStatus.getAdjustedFinanPoor()))
                testDriveStatus.setAdjustedFinanPoor(page.getAdjustedFinanPoor());
        }else {
            testDriveStatus.setAdjustedFinanPoor(page.getAdjustedFinanPoor());

        }

        if(null!=testDriveStatus.getAdjustedFinanFair()) {

            if (!page.getAdjustedFinanFair().equals(testDriveStatus.getAdjustedFinanFair()))
                testDriveStatus.setAdjustedFinanFair(page.getAdjustedFinanFair());
        }else {
            testDriveStatus.setAdjustedFinanFair(page.getAdjustedFinanFair());

        }

        if(null!=testDriveStatus.getAdjustedFinanGood()) {

            if (!page.getAdjustedFinanGood().equals(testDriveStatus.getAdjustedFinanGood()))
                testDriveStatus.setAdjustedFinanGood(page.getAdjustedFinanGood());
        }else {
            testDriveStatus.setAdjustedFinanGood(page.getAdjustedFinanGood());

        }

        if(null!=testDriveStatus.getAdjustedFinanVeryGood()) {

            if (!page.getAdjustedFinanVeryGood().equals(testDriveStatus.getAdjustedFinanVeryGood()))
                testDriveStatus.setAdjustedFinanVeryGood(page.getAdjustedFinanVeryGood());
        }else {
            testDriveStatus.setAdjustedFinanVeryGood(page.getAdjustedFinanVeryGood());

        }

        if(null!=testDriveStatus.getAdjustedFinanExcelnt()) {

            if (!page.getAdjustedFinanExcelnt().equals(testDriveStatus.getAdjustedFinanExcelnt()))
                testDriveStatus.setAdjustedFinanExcelnt(page.getAdjustedFinanExcelnt());
        }else {
            testDriveStatus.setAdjustedFinanExcelnt(page.getAdjustedFinanExcelnt());

        }

        if(null!=testDriveStatus.getAdjustedRetailPoor()) {

            if (!page.getAdjustedRetailPoor().equals(testDriveStatus.getAdjustedRetailPoor()))
                testDriveStatus.setAdjustedRetailPoor(page.getAdjustedRetailPoor());
        }else {
            testDriveStatus.setAdjustedRetailPoor(page.getAdjustedRetailPoor());

        }

        if(null!=testDriveStatus.getAdjustedRetailFair()) {

            if (!page.getAdjustedRetailFair().equals(testDriveStatus.getAdjustedRetailFair()))
                testDriveStatus.setAdjustedRetailFair(page.getAdjustedRetailFair());
        }else {
            testDriveStatus.setAdjustedRetailFair(page.getAdjustedRetailFair());

        }

        if(null!=testDriveStatus.getAdjustedRetailGood()) {

            if (!page.getAdjustedRetailGood().equals(testDriveStatus.getAdjustedRetailGood()))
                testDriveStatus.setAdjustedRetailGood(page.getAdjustedRetailGood());
        }else {
            testDriveStatus.setAdjustedRetailGood(page.getAdjustedRetailGood());

        }

        if(null!=testDriveStatus.getAdjustedRetailVeryGood()) {

            if (!page.getAdjustedRetailVeryGood().equals(testDriveStatus.getAdjustedRetailVeryGood()))
                testDriveStatus.setAdjustedRetailVeryGood(page.getAdjustedRetailVeryGood());
        }else {
            testDriveStatus.setAdjustedRetailVeryGood(page.getAdjustedRetailVeryGood());

        }

        if(null!=testDriveStatus.getAdjustedRetailExcelnt()) {

            if (!page.getAdjustedRetailExcelnt().equals(testDriveStatus.getAdjustedRetailExcelnt()))
                testDriveStatus.setAdjustedRetailExcelnt(page.getAdjustedRetailExcelnt());
        }else {
            testDriveStatus.setAdjustedRetailExcelnt(page.getAdjustedRetailExcelnt());

        }

        if(null!=testDriveStatus.getDealerReserve()) {

            if (!page.getDealerReserve().equals(testDriveStatus.getDealerReserve()))
                testDriveStatus.setDealerReserve(page.getDealerReserve());
        }else {
            testDriveStatus.setDealerReserve(page.getDealerReserve());

        }

        if(null!=testDriveStatus.getComsumerAskPrice()) {

            if (!page.getComsumerAskPrice().equals(testDriveStatus.getComsumerAskPrice()))
                testDriveStatus.setComsumerAskPrice(page.getComsumerAskPrice());
        }else {
            testDriveStatus.setComsumerAskPrice(page.getComsumerAskPrice());

        }

        if(null!=testDriveStatus.getDelrRetlAskPrice()) {

            if (!page.getDelrRetlAskPrice().equals(testDriveStatus.getDelrRetlAskPrice()))
                testDriveStatus.setDelrRetlAskPrice(page.getDelrRetlAskPrice());
        }else {
            testDriveStatus.setDelrRetlAskPrice(page.getDelrRetlAskPrice());

        }

        if(null!=testDriveStatus.getPushForBuyFig()) {

            if (!page.getPushForBuyFig().equals(testDriveStatus.getPushForBuyFig()))
                testDriveStatus.setPushForBuyFig(page.getPushForBuyFig());
        }else {
            testDriveStatus.setPushForBuyFig(page.getPushForBuyFig());

        }

        if(null!=testDriveStatus.getVehicleDesc()) {

            if (!page.getVehicleDesc().equals(testDriveStatus.getVehicleDesc()))
                testDriveStatus.setVehicleDesc(page.getVehicleDesc());
        }else {
            testDriveStatus.setVehicleDesc(page.getVehicleDesc());

        }


        if(null!=testDriveStatus.getVehiclePic1()) {

            if( updatePics(page.getVehiclePic1(), testDriveStatus.getVehiclePic1()) ) {

                testDriveStatus.setVehiclePic1(page.getVehiclePic1());
            }

        }else {
            testDriveStatus.setVehiclePic1(page.getVehiclePic1());

        }


        if(null!=testDriveStatus.getVehiclePic2()) {

            if( updatePics(page.getVehiclePic2(), testDriveStatus.getVehiclePic2()) ) {

                testDriveStatus.setVehiclePic2(page.getVehiclePic2());
            }

        }else {
            testDriveStatus.setVehiclePic2(page.getVehiclePic2());

        }

        if(null!=testDriveStatus.getVehiclePic3()) {

            if( updatePics(page.getVehiclePic3(), testDriveStatus.getVehiclePic3()) ) {

                testDriveStatus.setVehiclePic3(page.getVehiclePic3());
            }

        }else {
            testDriveStatus.setVehiclePic3(page.getVehiclePic3());

        }

        if(null!=testDriveStatus.getVehiclePic4()) {

            if( updatePics(page.getVehiclePic4(), testDriveStatus.getVehiclePic4()) ) {

                testDriveStatus.setVehiclePic4(page.getVehiclePic4());
            }
        }else {
            testDriveStatus.setVehiclePic4(page.getVehiclePic4());

        }

        if(null!=testDriveStatus.getVehiclePic5()) {

            if( updatePics(page.getVehiclePic5(), testDriveStatus.getVehiclePic5()) ) {

                testDriveStatus.setVehiclePic5(page.getVehiclePic5());
            }
        }else {
            testDriveStatus.setVehiclePic5(page.getVehiclePic5());

        }

        if(null!=testDriveStatus.getVehiclePic6()) {


            if( updatePics(page.getVehiclePic6(), testDriveStatus.getVehiclePic6()) ) {

                testDriveStatus.setVehiclePic6(page.getVehiclePic6());
            }
        }else {
            testDriveStatus.setVehiclePic6(page.getVehiclePic6());

        }


        if(null!=testDriveStatus.getVehiclePic7()) {


            if( updatePics(page.getVehiclePic7(), testDriveStatus.getVehiclePic7()) ) {

                testDriveStatus.setVehiclePic7(page.getVehiclePic7());
            }
        }else {
            testDriveStatus.setVehiclePic7(page.getVehiclePic7());

        }

        if(null!=testDriveStatus.getVehiclePic8()) {


            if( updatePics(page.getVehiclePic8(), testDriveStatus.getVehiclePic8()) ) {

                testDriveStatus.setVehiclePic8(page.getVehiclePic8());
            }
        }else {
            testDriveStatus.setVehiclePic8(page.getVehiclePic8());

        }

        if(null!=testDriveStatus.getVehiclePic9()) {

            if (updatePics(page.getVehiclePic9(), testDriveStatus.getVehiclePic9())) {

                testDriveStatus.setVehiclePic9(page.getVehiclePic9());
            }
        }
        else {
                testDriveStatus.setVehiclePic9(page.getVehiclePic9());

            }


            if (null != testDriveStatus.getVehicleVideo1()) {

                if (updatePics(page.getVehicleVideo1(), testDriveStatus.getVehicleVideo1())) {

                    testDriveStatus.setVehicleVideo1(page.getVehicleVideo1());
                }

            }
            else {
                testDriveStatus.setVehicleVideo1(page.getVehicleVideo1());
            }


        return testDriveStatus;
    }

    /**
     * this method update the database after checking with the List
     * @param eApprVehAcCondn this is coming from db
     * @param acCondition coming from ui
     * @return
     */
    private EApprVehAcCondn updateAcCondn(EApprVehAcCondn eApprVehAcCondn,List<String> acCondition){

        if(checkField(AppraisalConstants.COLD_AIR,acCondition)){
            eApprVehAcCondn.setColdAir(true);
        }else
            eApprVehAcCondn.setColdAir(false);

        if(checkField(AppraisalConstants.BAD_DISPLAY,acCondition)){
            eApprVehAcCondn.setBadDisplay(true);
        }else
            eApprVehAcCondn.setBadDisplay(false);

        if(checkField(AppraisalConstants.FADED_DISORBTN,acCondition)){
            eApprVehAcCondn.setFadedDisOrBtn(true);
        }else
            eApprVehAcCondn.setFadedDisOrBtn(false);

        if(checkField(AppraisalConstants.FANSPEEDMALFUN,acCondition)){
            eApprVehAcCondn.setFanSpeedMalfun(true);
        }else
            eApprVehAcCondn.setFanSpeedMalfun(false);

        if(checkField(AppraisalConstants.CLIMATECTRLMALFUN,acCondition)){
            eApprVehAcCondn.setClimateCtrlMalfun(true);
        }else
            eApprVehAcCondn.setClimateCtrlMalfun(false);

        if(checkField(AppraisalConstants.HOTORWARMAIR,acCondition)){
            eApprVehAcCondn.setHotOrWarmAir(true);
        }else
            eApprVehAcCondn.setHotOrWarmAir(false);

        if(checkField(AppraisalConstants.NOTOPERATIONAL,acCondition)){
            eApprVehAcCondn.setNotOperational(true);
        }else
            eApprVehAcCondn.setNotOperational(false);


     return eApprVehAcCondn;
    }

    /**
     * this method update the database after checking with the List
     * @param eVehDrWarnLightSts this is coming from database
     * @param dashWarningLights list is from ui
     * @return
     */

    private EVehDrWarnLightSts updateDrWarnLight(EVehDrWarnLightSts eVehDrWarnLightSts,List<String> dashWarningLights){

        if(checkField(AppraisalConstants.NOFAULTS,dashWarningLights)){
            eVehDrWarnLightSts.setNoFaults(true);
        }else
            eVehDrWarnLightSts.setNoFaults(false);
        if(checkField(AppraisalConstants.ABSLIGHT,dashWarningLights)){
            eVehDrWarnLightSts.setAbsLight(true);
        }else
            eVehDrWarnLightSts.setAbsLight(false);

        if(checkField(AppraisalConstants.AIRBAGFAULT,dashWarningLights)){
            eVehDrWarnLightSts.setAirBagFault(true);
        }else
            eVehDrWarnLightSts.setAirBagFault(false);

        if(checkField(AppraisalConstants.BATTERYFAULT,dashWarningLights)){
            eVehDrWarnLightSts.setBatteryFault(true);
        }else
            eVehDrWarnLightSts.setBatteryFault(false);

        if(checkField(AppraisalConstants.BRAKESYSTEM,dashWarningLights)){
            eVehDrWarnLightSts.setBrakeSystem(true);
        }else
            eVehDrWarnLightSts.setBrakeSystem(false);

        if(checkField(AppraisalConstants.BRAKEPADWEAR,dashWarningLights)){
            eVehDrWarnLightSts.setBrakePadWear(true);
        }else
            eVehDrWarnLightSts.setBrakePadWear(false);

        if(checkField(AppraisalConstants.CHARGINGSYSTEM,dashWarningLights)){
            eVehDrWarnLightSts.setChargingSystem(true);
        }else
            eVehDrWarnLightSts.setChargingSystem(false);

        if(checkField(AppraisalConstants.COOLANTLEVEL,dashWarningLights)){
            eVehDrWarnLightSts.setCoolantLevel(true);
        }else
            eVehDrWarnLightSts.setCoolantLevel(false);

        if(checkField(AppraisalConstants.COOLANTTEMP,dashWarningLights)){
            eVehDrWarnLightSts.setCoolantTemp(true);
        }else
            eVehDrWarnLightSts.setCoolantTemp(false);

        if(checkField(AppraisalConstants.CHECKENGINELIGHT,dashWarningLights)){
            eVehDrWarnLightSts.setCheckEngineLight(true);
        }else
            eVehDrWarnLightSts.setCheckEngineLight(false);

        if(checkField(AppraisalConstants.OILPRESSURE,dashWarningLights)){
            eVehDrWarnLightSts.setOilPressure(true);
        }else
            eVehDrWarnLightSts.setOilPressure(false);

        if(checkField(AppraisalConstants.SERVICEENGINESOON,dashWarningLights)){
            eVehDrWarnLightSts.setServiceEngineSoon(true);
        }else
            eVehDrWarnLightSts.setServiceEngineSoon(false);

        if(checkField(AppraisalConstants.STEERINGFAULTS,dashWarningLights)){
            eVehDrWarnLightSts.setSteeringFaults(true);
        }else
            eVehDrWarnLightSts.setSteeringFaults(false);
        if(checkField(AppraisalConstants.SUSPENSIONSYSTEM,dashWarningLights)){
            eVehDrWarnLightSts.setSuspensionSystem(true);
        }else
            eVehDrWarnLightSts.setSuspensionSystem(false);

        if(checkField(AppraisalConstants.TRACTIONCONTROL,dashWarningLights)){
            eVehDrWarnLightSts.setTractionControl(true);
        }else
            eVehDrWarnLightSts.setTractionControl(false);
        if(checkField(AppraisalConstants.TRANSMIFAULT,dashWarningLights)){
            eVehDrWarnLightSts.setTransmiFault(true);
        }else
            eVehDrWarnLightSts.setTransmiFault(false);
        if(checkField(AppraisalConstants.DISLEXHFLUIDLIGHT,dashWarningLights)){
            eVehDrWarnLightSts.setDislExhFluidLight(true);
        }else
            eVehDrWarnLightSts.setDislExhFluidLight(false);
        if(checkField(AppraisalConstants.DISLPARTICULATEFILT,dashWarningLights)){
            eVehDrWarnLightSts.setDislParticulateFilt(true);
        }else
            eVehDrWarnLightSts.setDislParticulateFilt(false);


        return eVehDrWarnLightSts;
    }

    /**
     * this method update the database after checking with the List
     * @param eApprVehStereoSts this is coming from database
     * @param stereoStatus list is from ui
     * @return
     */

    private EApprVehStereoSts updateStereoSts (EApprVehStereoSts eApprVehStereoSts,List<String> stereoStatus){

        if(checkField(AppraisalConstants.FACTORYEQUPTOPERAT,stereoStatus)){
            eApprVehStereoSts.setFactoryEquptOperat(true);
        }else
            eApprVehStereoSts.setFactoryEquptOperat(false);
        if(checkField(AppraisalConstants.FACTORYEQUPTNOTOPERAT,stereoStatus)){
            eApprVehStereoSts.setFactoryEquptNotOperat(true);
        }else
            eApprVehStereoSts.setFactoryEquptNotOperat(false);
        if(checkField(AppraisalConstants.KNOBSMISSING,stereoStatus)){
            eApprVehStereoSts.setKnobsMissing(true);
        }else
            eApprVehStereoSts.setKnobsMissing(false);
        if(checkField(AppraisalConstants.AFTMKTNAVIGANICESYS,stereoStatus)){
            eApprVehStereoSts.setAftMktNavigaNiceSys(true);
        }else
            eApprVehStereoSts.setAftMktNavigaNiceSys(false);

        if(checkField(AppraisalConstants.AFTERMARKET,stereoStatus)){
            eApprVehStereoSts.setAfterMarket(true);
        }else
            eApprVehStereoSts.setAfterMarket(false);

        if(checkField(AppraisalConstants.AFTMKTREARENTERTAINSYS,stereoStatus)){
            eApprVehStereoSts.setAftMktRearEntertainSys(true);
        }else
            eApprVehStereoSts.setAftMktRearEntertainSys(false);

        if(checkField(AppraisalConstants.FACTORYREARENTERTAINSYS,stereoStatus)){
            eApprVehStereoSts.setFactoryRearEntertainSys(true);
        }else
            eApprVehStereoSts.setFactoryRearEntertainSys(false);
        if(checkField(AppraisalConstants.PROFINSTALL,stereoStatus)){
            eApprVehStereoSts.setProfInstall(true);
        }else
            eApprVehStereoSts.setProfInstall(false);

        if(checkField(AppraisalConstants.BROKENSCREEN,stereoStatus)){
            eApprVehStereoSts.setBrokenScreen(true);
        }else
            eApprVehStereoSts.setBrokenScreen(false);
        if(checkField(AppraisalConstants.FADEDDISBTN,stereoStatus)){
            eApprVehStereoSts.setFadedDisBtn(true);
        }else
            eApprVehStereoSts.setFadedDisBtn(false);

        if(checkField(AppraisalConstants.NOTOPERATIONAL,stereoStatus)){
            eApprVehStereoSts.setNotOperational(true);
        }else
            eApprVehStereoSts.setNotOperational(false);

        if(checkField(AppraisalConstants.OPERATIONAL,stereoStatus)){
            eApprVehStereoSts.setOperational(true);
        }else
            eApprVehStereoSts.setOperational(false);


        return eApprVehStereoSts;
    }

    /**
     * this method update the database after checking with the list of oilCondition and return updated object
     * @param eApprVehOilCondn this is coming from database
     * @param oilCondition list coming from ui
     * @return
     */

    private EApprVehOilCondn updateOilCondn (EApprVehOilCondn eApprVehOilCondn,List<String> oilCondition){
        if(checkField(AppraisalConstants.CLEANOIL,oilCondition)){
            eApprVehOilCondn.setCleanOil(true);
        }else
            eApprVehOilCondn.setCleanOil(false);
        if(checkField(AppraisalConstants.DIRTYOIL,oilCondition)){
            eApprVehOilCondn.setDirtyOil(true);
        }else
            eApprVehOilCondn.setDirtyOil(false);
        if(checkField(AppraisalConstants.WATERINOIL,oilCondition)){
            eApprVehOilCondn.setWaterInOil(true);
        }else
            eApprVehOilCondn.setWaterInOil(false);
        if(checkField(AppraisalConstants.ONEQUARTLOW,oilCondition)){
            eApprVehOilCondn.setOneQuartLow(true);
        }else
            eApprVehOilCondn.setOneQuartLow(false);
        if(checkField(AppraisalConstants.GREATERTHANAQUARTLOW,oilCondition)){
            eApprVehOilCondn.setGreaterThanAQuartLow(true);
        }else
            eApprVehOilCondn.setGreaterThanAQuartLow(false);
        if(checkField(AppraisalConstants.ELECTRONICGAUGE,oilCondition)){
            eApprVehOilCondn.setElectronicGauge(true);
        }else
            eApprVehOilCondn.setElectronicGauge(false);


        return eApprVehOilCondn;
    }

    /**
     * This method updates the Interior condition and retuns the updated object
     * @param intrCondn this parameter is from database
     * @param interiorCondition list coming from ui
     * @return
     */
    private EApprVehInteriCondn updateInteriCondn (EApprVehInteriCondn intrCondn,List<String> interiorCondition){

        if(checkField(AppraisalConstants.CLEANFL,interiorCondition)){
            intrCondn.setCleanFL(true);
        }else
            intrCondn.setCleanFL(false);
        if(checkField(AppraisalConstants.GOODMNRREPAISNEED,interiorCondition)){
            intrCondn.setGoodMnrRepaisNeed(true);
        }else
            intrCondn.setGoodMnrRepaisNeed(false);
        if(checkField(AppraisalConstants.SMOKERSCAR,interiorCondition)){
            intrCondn.setSmokersCar(true);
        }else
            intrCondn.setSmokersCar(false);

        if(checkField(AppraisalConstants.ODDSMELLING,interiorCondition)){
            intrCondn.setOddSmelling(true);
        }else
            intrCondn.setOddSmelling(false);

        if(checkField(AppraisalConstants.VERYDIRTY,interiorCondition)){
            intrCondn.setVeryDirty(true);
        }else
            intrCondn.setVeryDirty(false);
        if(checkField(AppraisalConstants.STRONGPETSMELL,interiorCondition)){
            intrCondn.setStrongPetSmell(true);
        }else
            intrCondn.setStrongPetSmell(false);

        if(checkField(AppraisalConstants.DRIVERSSEATWEAR,interiorCondition)){
            intrCondn.setDriversSeatWear(true);
        }else
            intrCondn.setDriversSeatWear(false);
        if(checkField(AppraisalConstants.HEADLINENEEDRPLC,interiorCondition)){
            intrCondn.setHeadlineNeedRplc(true);
        }else
            intrCondn.setHeadlineNeedRplc(false);
        if(checkField(AppraisalConstants.DRIVERSEATRIPPED,interiorCondition)){
            intrCondn.setDriverSeatRipped(true);
        }else
            intrCondn.setDriverSeatRipped(false);
        if(checkField(AppraisalConstants.CARPETBADLYWORN,interiorCondition)){
            intrCondn.setCarpetBadlyWorn(true);
        }else
            intrCondn.setCarpetBadlyWorn(false);
        if(checkField(AppraisalConstants.INTERTRIMBRKNNMISS,interiorCondition)){
            intrCondn.setInterTrimBrknnMiss(true);
        }else
            intrCondn.setInterTrimBrknnMiss(false);
        if(checkField(AppraisalConstants.POORNEEDSREPAIR,interiorCondition)){
            intrCondn.setPoorNeedsRepair(true);
        }else
            intrCondn.setPoorNeedsRepair(false);

        return intrCondn;
    }

    /**
     * This method checks the field is available in List if present returns true
     * @param value constants
     * @param list this list coming from ui
     * @return
     */
    private Boolean checkField(String value,List<String> list){
        return list.contains(value);
    }

}
