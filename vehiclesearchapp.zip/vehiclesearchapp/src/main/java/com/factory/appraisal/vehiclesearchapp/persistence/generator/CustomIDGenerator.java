//package com.factory.appraisal.vehiclesearchapp.persistence.generator;
//
//import org.hibernate.HibernateException;
//import org.hibernate.MappingException;
//import org.hibernate.Session;
//import org.hibernate.dialect.Dialect;
//import org.hibernate.engine.jdbc.env.spi.JdbcEnvironment;
//import org.hibernate.engine.spi.SharedSessionContractImplementor;
//import org.hibernate.id.Configurable;
//import org.hibernate.id.IdentifierGenerator;
//import org.hibernate.id.enhanced.SequenceStyleGenerator;
//import org.hibernate.internal.util.config.ConfigurationHelper;
//import org.hibernate.service.ServiceRegistry;
//import org.hibernate.type.Type;
//
//import java.io.Serializable;
//import java.text.SimpleDateFormat;
//import java.time.LocalDate;
//import java.time.format.DateTimeFormatter;
//import java.util.Date;
//import java.util.Properties;
//
//public class CustomIDGenerator implements IdentifierGenerator, Configurable {
//
//
//    private String sequenceCallSyntax;
//    private static final DateTimeFormatter monthFormatter
//            = DateTimeFormatter.ofPattern("MM");
//
//    private static final DateTimeFormatter yearFormatter=DateTimeFormatter.ofPattern("yy");
//
//    @Override
//    public Serializable generate(SharedSessionContractImplementor session, Object o) throws HibernateException {
//        LocalDate date=LocalDate.now();
//        String prefix=date.format(yearFormatter).concat(date.format(monthFormatter));
//        long seqValue = ((Number)
//                Session.class.cast(session)
//                        .createNativeQuery(sequenceCallSyntax)
//                        .uniqueResult()
//        ).longValue();
//
//        String genId=prefix.concat(String.valueOf(seqValue));
//
//        return Long.valueOf(genId);
//    }
//
//    @Override
//    public void configure(Type type, Properties properties, ServiceRegistry serviceRegistry) throws MappingException {
//        final JdbcEnvironment jdbcEnvironment = serviceRegistry
//                .getService(
//                        JdbcEnvironment.class
//                );
//        final Dialect dialect = jdbcEnvironment.getDialect();
//        boolean preferSequencePerEntity = ConfigurationHelper
//                .getBoolean(
//                        SequenceStyleGenerator.CONFIG_PREFER_SEQUENCE_PER_ENTITY,
//                        properties,
//                        false
//                );
//        String seqName=properties.getProperty("schema").concat(".").concat(properties.getProperty("sequence"));
//
//        sequenceCallSyntax = dialect
//                .getSequenceNextValString(
//                        ConfigurationHelper.getString(
//                                SequenceStyleGenerator.SEQUENCE_PARAM,
//                                properties,
//                                seqName
//                        )
//                );
//
//    }
//}
